/* ==========================================
   STATE MANAGEMENT & GLOBAL VARIABLES
   ========================================== */
let studentTests = [];
let userTestResultsMap = {}; 
let userDraftsMap = {};      
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
let isExploreOpen = false;

// Selection Variables for Test Start Modal
let pendingTestStart = { testId: null, isReattempt: false, isResume: false };
let selectedMode = 'quiz'; // Default 'quiz'

// Pagination variables
let visibleTestCount = 5; // Start me sirf 5 dikhenge
function loadMoreTests() {
    visibleTestCount += 10; // Batch size increment
    renderRecentFiveTests();
}

// Selection State Tracker for Explore Section (Student Tests)
let selectedBoard = "ALL";
let selectedClass = "ALL";
let selectedSubject = "ALL";

// Selection State Tracker for Leaderboard Step-by-Step Filters
let selectedLbBoard = "ALL";
let selectedLbClass = "ALL";
let selectedLbSubject = "ALL";
let selectedLbTestId = "ALL";

// Dynamic CSS Injection for Skeleton, Touch Optimizations & UI Enhancements
(function injectCustomStyles() {
    const style = document.createElement('style');
    style.innerHTML = `
        /* Touch & Long-Tap Optimizations for Mobile Browsers */
        button, .chip-btn, .test-card, .podium-card {
            -webkit-tap-highlight-color: transparent !important;
            touch-action: manipulation !important;
            user-select: none !important;
        }

        @keyframes skeleton-pulse {
            0% { background-color: #e2e8f0; }
            50% { background-color: #edf2f7; }
            100% { background-color: #e2e8f0; }
        }
        .skeleton-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 16px;
            border: 1px solid #e2e8f0;
            display: flex;
            flex-direction: column;
            gap: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .skeleton-line {
            height: 14px;
            background-color: #e2e8f0;
            border-radius: 4px;
            animation: skeleton-pulse 1.5s infinite ease-in-out;
        }
        .btn-reattempt {
            background: transparent !important;
            color: #4b5563 !important;
            border: 1.5px solid #cbd5e1 !important;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .btn-reattempt:hover, .btn-reattempt:active {
            background: #f1f5f9 !important;
            color: #1e293b !important;
            border-color: #94a3b8 !important;
        }
        .btn-resume {
            background: #f59e0b !important;
            color: #ffffff !important;
            border: none !important;
            font-weight: 700 !important;
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3) !important;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .btn-resume:hover, .btn-resume:active {
            background: #d97706 !important;
        }
        .btn-share {
            background: #25D366;
            color: #ffffff;
            border: none;
            padding: 5px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: opacity 0.2s;
        }
        .btn-share:hover, .btn-share:active { opacity: 0.9; }
    `;
    document.head.appendChild(style);
})();

/* ==========================================
   INITIALIZATION & AUTHENTICATION
   ========================================== */
document.addEventListener("DOMContentLoaded", async () => {
    initDarkModeSupport();

    if (window.supabaseClient) {
        try {
            const { data: { session } } = await window.supabaseClient.auth.getSession();
            isLoggedIn = !!(session && session.user);
            localStorage.setItem("isLoggedIn", isLoggedIn ? "true" : "false");

            window.supabaseClient.auth.onAuthStateChange((_event, session) => {
                isLoggedIn = !!(session && session.user);
                localStorage.setItem("isLoggedIn", isLoggedIn ? "true" : "false");
            });
        } catch (e) {
            console.warn("Supabase auth error:", e);
        }
    }

    const searchInput = document.getElementById("searchInput");
    if (searchInput) {
        searchInput.addEventListener("input", filterStudentTests);
    }

    scanLocalDrafts();
    await fetchUserPreviousResults();
    await fetchStudentTests();

    // Mini preview se aaye ho to filter/search/tab wahi se continue
    initMiniStateForTests();

    // Catch Leaderboard Query Parameter from URL
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    if (tabParam === 'leaderboard') {
        switchTab('leaderboard');
    }
});

/* ==========================================
   MINI PREVIEW -> FULL SCREEN: filters, search, tab continue
   (test attempt ka progress pehle se testscript.js ke draft me save hota hai)
   ========================================== */
function initMiniStateForTests() {
    if (!window.Mini) return;

    Mini.onSnapshot(function () {
        var si = document.getElementById("searchInput");
        var leaderSec = document.getElementById("leaderboardSection");
        return {
            board: selectedBoard,
            cls: selectedClass,
            sub: selectedSubject,
            q: si ? si.value : "",
            open: isExploreOpen,
            tab: (leaderSec && leaderSec.style.display === "block") ? "leaderboard" : "tests",
            count: visibleTestCount
        };
    });

    var s = Mini.take();
    if (!s) return;

    try {
        if (s.count && s.count > visibleTestCount) visibleTestCount = s.count;
        if (s.open && !isExploreOpen) toggleExplorePage();
        if (s.board && s.board !== "ALL") selectBoard(s.board);
        if (s.cls && s.cls !== "ALL") selectClass(s.cls);
        if (s.sub && s.sub !== "ALL") selectSubject(s.sub);

        var si = document.getElementById("searchInput");
        if (si && s.q) si.value = s.q;
        filterStudentTests();

        if (s.tab === "leaderboard") switchTab("leaderboard");
    } catch (e) {
        console.warn("Mini restore failed:", e);
    }
}

function initDarkModeSupport() {
    const modeToggle = document.getElementById("modeToggle");
    // Auto theme: din (6am-6pm) light, raat dark. User toggle dabaye to wahi (localStorage "theme") chalega;
    // cache clear hone par auto wapas.
    const manual = () => { const v = localStorage.getItem("theme"); return v === "dark" || v === "light" ? v : null; };
    const wantDark = () => {
        const m = manual();
        if (m) return m === "dark";
        const h = new Date().getHours();
        return !(h >= 6 && h < 18);
    };
    const apply = () => {
        const dark = wantDark();
        document.body.classList.toggle("dark", dark);
        document.body.classList.toggle("dark-mode", dark);
        if (modeToggle) modeToggle.checked = dark;
    };
    apply();

    if (modeToggle) {
        modeToggle.addEventListener("change", function () {
            localStorage.setItem("theme", this.checked ? "dark" : "light");
            apply();
        });
    }
    setInterval(() => { if (!manual()) apply(); }, 60000);
    window.addEventListener("storage", (e) => { if (e.key === "theme") apply(); });
}

/* ==========================================
   LOCAL DRAFTS DETECTOR (CONTINUE FEATURE)
   ========================================== */
function scanLocalDrafts() {
    userDraftsMap = {};
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith("test_draft_")) {
            const testId = key.replace("test_draft_", "");
            try {
                const draftData = JSON.parse(localStorage.getItem(key));
                if (draftData) {
                    userDraftsMap[testId] = draftData;
                }
            } catch (e) {
                console.warn("Invalid draft format for key:", key);
            }
        }
    }
}

/* ==========================================
   FETCH USER PREVIOUS TEST RESULTS
   ========================================== */
async function fetchUserPreviousResults() {
    if (!window.supabaseClient) return;

    try {
        const { data: { user } } = await window.supabaseClient.auth.getUser();
        if (!user) return;

        const { data, error } = await window.supabaseClient
            .from('test_results')
            .select('test_id, score, total_marks, created_at')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false });

        if (error) throw error;

        userTestResultsMap = {};
        if (data && data.length > 0) {
            data.forEach(result => {
                if (!userTestResultsMap[result.test_id]) {
                    const total = result.total_marks || 0;
                    const score = result.score || 0;
                    const pct = total > 0 ? Math.round((score / total) * 100) : 0;
                    
                    userTestResultsMap[result.test_id] = {
                        score: score,
                        total_marks: total,
                        percentage: pct
                    };
                }
            });
        }
    } catch (err) {
        console.warn("Error fetching user test history:", err.message);
    }
}

/* ==========================================
   LOADING SKELETON RENDERER & SPINNER HIDER
   ========================================== */
function hideGlobalSpinner() {
    const allSpinners = document.querySelectorAll('.fetching-tests-spinner, [class*="spinner"], [id*="loading"]');
    allSpinners.forEach(el => {
        if (el.id !== "studentTestsContainer" && el.id !== "leaderboardLoader") el.remove();
    });

    const loaderBox = document.getElementById("loaderBox");
    if (loaderBox) loaderBox.style.display = "none";
}

function showLoadingSkeletons() {
    const container = document.getElementById("studentTestsContainer");
    if (!container) return;

    let skeletonHtml = "";
    for (let i = 0; i < 4; i++) {
        skeletonHtml += `
            <div class="skeleton-card">
                <div class="skeleton-line" style="width: 70%; height: 20px;"></div>
                <div class="skeleton-line" style="width: 40%; height: 12px;"></div>
                <div class="skeleton-line" style="width: 100%; height: 35px; margin-top: 10px;"></div>
                <div class="skeleton-line" style="width: 100%; height: 40px; border-radius: 8px;"></div>
            </div>
        `;
    }
    container.innerHTML = skeletonHtml;
}

/* ==========================================
   DATA FETCHING & RENDERING
   ========================================== */
async function fetchStudentTests() {
    showLoadingSkeletons();

    try {
        const { data, error } = await window.supabaseClient
            .from('tests')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        studentTests = data || [];
        populateLeaderboardTestDropdown(studentTests);
        initLeaderboardStepView();
        
        // Initial state reset to 5
        visibleTestCount = 5;
        renderRecentFiveTests();
    } catch (err) {
        const statusMsg = document.getElementById("statusMsg");
        if (statusMsg) {
            statusMsg.style.display = "block";
            statusMsg.innerText = "❌ Error loading tests: " + err.message;
        }
    } finally {
        hideGlobalSpinner();
    }
}

function renderRecentFiveTests() {
    const headingTitle = document.getElementById("headingTitle");
    const testCountBadge = document.getElementById("testCountBadge");
    
    if (headingTitle) headingTitle.innerHTML = `<i class="fa-solid fa-bolt" style="color: #f6e05e;"></i> Recently Added Tests`;
    
    // Slice based on visibleTestCount
    const testsToDisplay = studentTests.slice(0, visibleTestCount);
    
    if (testCountBadge) {
        testCountBadge.innerText = `${testsToDisplay.length} of ${studentTests.length}`;
    }

    const remainingCount = studentTests.length - visibleTestCount;
    const showLoadMoreBtn = remainingCount > 0;

    renderStudentTests(testsToDisplay, showLoadMoreBtn, remainingCount);
}

/* ==========================================
   EXPLORE & FILTER STEP LOGIC (TESTS SECTION)
   ========================================== */
function toggleExplorePage() {
    const pageView = document.getElementById("explorePageView");
    const chevron = document.getElementById("exploreChevron");
    
    if (!pageView) return;

    if (pageView.style.display === "none" || pageView.style.display === "") {
        pageView.style.display = "block";
        if (chevron) chevron.className = "fa-solid fa-chevron-up";
        isExploreOpen = true;
        renderBoardStep();
    } else {
        pageView.style.display = "none";
        if (chevron) chevron.className = "fa-solid fa-chevron-down";
        isExploreOpen = false;
        renderRecentFiveTests();
    }
}

function renderBoardStep() {
    const grid = document.getElementById("boardOptionsGrid");
    if (!grid) return;

    const availableBoards = new Set();
    studentTests.forEach(test => {
        const title = (test.title || "").toUpperCase();
        if (title.includes("BSEB") || title.includes("BIHAR")) availableBoards.add("BSEB");
        else if (title.includes("CBSE")) availableBoards.add("CBSE");
        else if (title.includes("NEET")) availableBoards.add("NEET");
        else if (title.includes("JEE")) availableBoards.add("JEE");
    });

    let html = `<button class="chip-btn ${selectedBoard === 'ALL' ? 'active' : ''}" onclick="selectBoard('ALL')">All Boards</button>`;
    
    availableBoards.forEach(board => {
        const activeClass = selectedBoard === board ? 'active' : '';
        html += `<button class="chip-btn ${activeClass}" onclick="selectBoard('${board}')">${board}</button>`;
    });

    grid.innerHTML = html;
}

function selectBoard(board) {
    selectedBoard = board;
    selectedClass = "ALL";
    selectedSubject = "ALL";

    renderBoardStep();
    
    const classBlock = document.getElementById("classStepBlock");
    const subjectBlock = document.getElementById("subjectStepBlock");

    if (classBlock) classBlock.style.display = "block";
    if (subjectBlock) subjectBlock.style.display = "none";
    
    renderClassStep();
    filterStudentTests();
}

function renderClassStep() {
    const grid = document.getElementById("classOptionsGrid");
    if (!grid) return;

    const availableClasses = new Set();
    
    studentTests.forEach(test => {
        const fullText = `${test.title || ''} ${test.class_level || ''}`.toUpperCase();
        
        let boardMatch = (selectedBoard === "ALL") || 
            (selectedBoard === "BSEB" && (fullText.includes("BSEB") || fullText.includes("BIHAR"))) ||
            fullText.includes(selectedBoard.toUpperCase());

        if (boardMatch) {
            if (test.class_level && test.class_level.trim() !== "") {
                availableClasses.add(test.class_level.trim());
            } else if (fullText.includes("12")) availableClasses.add("Class 12th");
            else if (fullText.includes("11")) availableClasses.add("Class 11th");
            else if (fullText.includes("10")) availableClasses.add("Class 10th");
        }
    });

    let html = `<button class="chip-btn ${selectedClass === 'ALL' ? 'active' : ''}" onclick="selectClass('ALL')">All Classes</button>`;
    
    availableClasses.forEach(cls => {
        const activeClass = selectedClass === cls ? 'active' : '';
        html += `<button class="chip-btn ${activeClass}" onclick="selectClass('${cls}')">${cls}</button>`;
    });

    grid.innerHTML = html;
}

function selectClass(cls) {
    selectedClass = cls;
    selectedSubject = "ALL";

    renderClassStep();

    const subjectBlock = document.getElementById("subjectStepBlock");
    if (subjectBlock) subjectBlock.style.display = "block";
    
    renderSubjectStep();
    filterStudentTests();
}

function renderSubjectStep() {
    const grid = document.getElementById("subjectOptionsGrid");
    if (!grid) return;

    const availableSubjects = new Set();

    studentTests.forEach(test => {
        const fullText = `${test.title || ''} ${test.class_level || ''}`.toUpperCase();
        
        let boardMatch = (selectedBoard === "ALL") || 
            (selectedBoard === "BSEB" && (fullText.includes("BSEB") || fullText.includes("BIHAR"))) ||
            fullText.includes(selectedBoard.toUpperCase());

        // Strict Class Match
        let testClassClean = (test.class_level || '').trim().toLowerCase();
        let selectedClassClean = selectedClass.trim().toLowerCase();
        
        let classMatch = (selectedClass === "ALL") ||
            (test.class_level && testClassClean === selectedClassClean) ||
            (selectedClassClean.includes("10") && (testClassClean.includes("10") || fullText.includes("10TH") || fullText.includes("CLASS 10")) && !testClassClean.includes("12") && !fullText.includes("12TH")) ||
            (selectedClassClean.includes("11") && (testClassClean.includes("11") || fullText.includes("11TH") || fullText.includes("CLASS 11"))) ||
            (selectedClassClean.includes("12") && (testClassClean.includes("12") || fullText.includes("12TH") || fullText.includes("CLASS 12")));

        if (boardMatch && classMatch && test.subject) {
            availableSubjects.add(test.subject.trim());
        }
    });

    let html = `<button class="chip-btn ${selectedSubject === 'ALL' ? 'active' : ''}" onclick="selectSubject('ALL')">All Subjects</button>`;
    
    availableSubjects.forEach(sub => {
        const activeClass = selectedSubject === sub ? 'active' : '';
        html += `<button class="chip-btn ${activeClass}" onclick="selectSubject('${sub}')">${sub}</button>`;
    });

    grid.innerHTML = html;
}

function selectSubject(sub) {
    selectedSubject = sub;
    renderSubjectStep();
    filterStudentTests();
}

function resetExploreSelections() {
    selectedBoard = "ALL";
    selectedClass = "ALL";
    selectedSubject = "ALL";
    
    const searchInput = document.getElementById("searchInput");
    if (searchInput) searchInput.value = "";
    
    const classBlock = document.getElementById("classStepBlock");
    const subjectBlock = document.getElementById("subjectStepBlock");
    
    if (classBlock) classBlock.style.display = "none";
    if (subjectBlock) subjectBlock.style.display = "none";
    
    renderBoardStep();
    filterStudentTests();
}

/* ==========================================
   DYNAMIC MULTI-FILTER ENGINE (STUDENT TESTS)
   ========================================== */
function filterStudentTests() {
    const searchInput = document.getElementById("searchInput");
    var searchVal = searchInput ? searchInput.value.toLowerCase().trim() : "";

    if (searchVal !== "" && !isExploreOpen) {
        toggleExplorePage();
    }

    if (!isExploreOpen && searchVal === "" && selectedBoard === "ALL" && selectedClass === "ALL" && selectedSubject === "ALL") {
        renderRecentFiveTests();
        return;
    }

    var filtered = studentTests.filter(function(test) {
        var testTitle = (test.title || '').toLowerCase();
        var testClassLevel = (test.class_level || '').trim().toLowerCase();
        var testSubject = (test.subject || '').trim().toLowerCase();

        var combinedSearchText = testTitle + " " + testClassLevel + " " + testSubject;

        var matchesSearch = searchVal === "" || combinedSearchText.indexOf(searchVal) !== -1;

        var matchesBoard = (selectedBoard === "ALL") ||
                           (selectedBoard === "BSEB" && (combinedSearchText.indexOf("bseb") !== -1 || combinedSearchText.indexOf("bihar") !== -1)) ||
                           combinedSearchText.indexOf(selectedBoard.toLowerCase()) !== -1;

        var selectedClassClean = selectedClass.trim().toLowerCase();
        var matchesClass = (selectedClass === "ALL") ||
                           (test.class_level && testClassLevel === selectedClassClean) ||
                           (selectedClassClean.includes("10") && (testClassLevel.includes("10") || testTitle.includes("class 10") || testTitle.includes("10th")) && !testClassLevel.includes("12") && !testTitle.includes("12th")) ||
                           (selectedClassClean.includes("11") && (testClassLevel.includes("11") || testTitle.includes("class 11") || testTitle.includes("11th"))) ||
                           (selectedClassClean.includes("12") && (testClassLevel.includes("12") || testTitle.includes("class 12") || testTitle.includes("12th")));

        var matchesSubject = (selectedSubject === "ALL") ||
                             testSubject.indexOf(selectedSubject.toLowerCase()) !== -1;

        return matchesSearch && matchesBoard && matchesClass && matchesSubject;
    });

    const headingTitle = document.getElementById("headingTitle");
    const testCountBadge = document.getElementById("testCountBadge");
    
    if (headingTitle) headingTitle.innerHTML = `<i class="fa-solid fa-list-check" style="color: #4A00E0;"></i> Filtered Tests`;
    if (testCountBadge) testCountBadge.innerText = filtered.length + " Found";

    renderStudentTests(filtered, false);
}


function renderStudentTests(tests, showLoadMoreBtn = false, remainingCount = 0) {

    const container = document.getElementById("studentTestsContainer");
    if (!container) return;

    hideGlobalSpinner();
    scanLocalDrafts();

    if (tests.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px 20px;">
                <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 auto 12px auto; display: block;">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <h4 style="color: #475569; font-size: 16px; margin-bottom: 4px;">Koi Test Nahi Mila</h4>
                <p style="color: #94a3b8; font-size: 13px;">Kripya apne filters ya search query badal kar dekhein.</p>
            </div>
        `;
        return;
    }

    let html = "";
    tests.forEach(test => {
        let qCount = test.questions_data ? test.questions_data.length : 0;
        let timeMins = test.time_limit_mins || 15;
        let classBadge = test.class_level ? `<span style="background: #edf2f7; color: #4a5568; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-left: 6px;">${test.class_level}</span>` : '';

        // Check if New
        let isNew = false;
        if (test.created_at) {
            const testDate = new Date(test.created_at);
            const now = new Date();
            const diffDays = (now - testDate) / (1000 * 60 * 60 * 24);
            if (diffDays >= 0 && diffDays <= 7) isNew = true;
        }
        let newBadgeHtml = isNew ? `<span class="badge-new">NEW</span>` : '';

        // Medium Badge Detection (हिंदी, English, Hinglish)
        let mediumText = test.medium || test.language || 'Hinglish';
        if (!test.medium && !test.language) {
            let fullTxt = `${test.title || ''} ${test.subject || ''}`.toLowerCase();
            if (fullTxt.includes('hindi') || fullTxt.includes('हिंदी')) mediumText = 'हिंदी';
            else if (fullTxt.includes('english')) mediumText = 'English';
        }
        let mediumBadgeHtml = `<span class="badge-medium">${mediumText}</span>`;

        let statusBlockHtml = '';
        let buttonText = 'Start Test';
        let buttonIcon = 'fa-arrow-right';
        let buttonClass = 'btn-primary';
        let isReattempt = false;
        let isResume = false;

        const draft = userDraftsMap[test.id];
        const hasDraft = !!draft;
        const prevStats = userTestResultsMap[test.id];

        if (hasDraft) {
            buttonText = 'Resume Test';
            buttonIcon = 'fa-play';
            buttonClass = 'btn-resume';
            isResume = true;
            const answers = draft.userAnswers || draft.user_answers || {};
            const attemptedCount = Object.keys(answers).length;
            
            statusBlockHtml = `
                <div style="margin-top: 10px; padding: 8px 10px; background: rgba(245, 158, 11, 0.1); border-left: 3px solid #f59e0b; border-radius: 6px; font-size: 11px; font-weight: 700; color: #b45309; display: flex; justify-content: space-between; align-items: center;">
                    <span><i class="fa-solid fa-pause-circle"></i> In Progress (${attemptedCount}/${qCount} Ans)</span>
                    <span style="font-size: 10px; background: #f59e0b; color:#fff; padding:2px 6px; border-radius:4px;">Unfinished</span>
                </div>
            `;
        } else if (prevStats) {
            buttonText = 'Reattempt Test';
            buttonIcon = 'fa-rotate-right';
            buttonClass = 'btn-reattempt';
            isReattempt = true;

            let badgeColor = prevStats.percentage >= 60 ? '#10b981' : (prevStats.percentage >= 40 ? '#f59e0b' : '#ef4444');
            const safeTitle = (test.title || '').replace(/'/g, "\\'").replace(/"/g, "&quot;");
            
            statusBlockHtml = `
                <div style="margin-top: 10px; padding: 8px 10px; background: rgba(0,0,0,0.03); border-left: 3px solid ${badgeColor}; border-radius: 6px; font-size: 11px; font-weight: 700; color: #4b5563; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span><i class="fa-solid fa-chart-line" style="color:${badgeColor}; margin-right: 4px;"></i> Last Attempt:</span>
                        <span style="color:${badgeColor}; font-weight: 800; margin-left: 4px;">${prevStats.score}/${prevStats.total_marks} (${prevStats.percentage}%)</span>
                    </div>
                    <button class="btn-share" onclick="shareTestScore('${safeTitle}', ${prevStats.score}, ${prevStats.total_marks}, ${prevStats.percentage}, '${test.id}')">
                        <i class="fa-brands fa-whatsapp"></i> Share Link
                    </button>
                </div>
            `;
        }

        html += `
            <div class="test-card">
                <div class="card-badges-container">
                    ${newBadgeHtml}
                    ${mediumBadgeHtml}
                </div>
                <div class="test-card-header" style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px;">
                    <h3>${test.title} ${classBadge}</h3>
                </div>
                <div class="test-meta">
                    <span><i class="fa-solid fa-file-alt"></i> ${qCount} Qs</span> • 
                    <span><i class="fa-solid fa-clock"></i> ${timeMins} Mins</span> • 
                    <span><i class="fa-solid fa-book"></i> ${test.subject || 'General'}</span>
                </div>
                ${statusBlockHtml}
                <button class="${buttonClass}" onclick="handleStartTest('${test.id}', ${isReattempt}, ${isResume})" style="margin-top: 12px; width: 100%;">
                    ${buttonText} <i class="fa-solid ${buttonIcon}"></i>
                </button>
            </div>
        `;
    });

    if (showLoadMoreBtn) {
        const nextBatchSize = Math.min(10, remainingCount);

        html += `
            <div class="load-more-wrapper" style="grid-column: 1 / -1; text-align: center; margin-top: 20px;">
                <button onclick="loadMoreTests()" class="btn-load-more">
                    <i class="fa-solid fa-circle-arrow-down"></i> Load More (${nextBatchSize}) — ${remainingCount} Remaining
                </button>
            </div>
        `;
    }

    container.innerHTML = html;
}

/* ==========================================
   DEVICE ORIENTATION & TILT EFFECTS
   ========================================== */
document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll(".test-card, .podium-card");
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

    if (isMobile && window.DeviceOrientationEvent) {
        window.addEventListener("deviceorientation", (event) => {
            let tiltX = event.beta;
            let tiltY = event.gamma;

            if (tiltX === null || tiltY === null) return;

            tiltX = Math.max(-30, Math.min(30, tiltX));
            tiltY = Math.max(-30, Math.min(30, tiltY));

            cards.forEach(card => {
                card.style.transform = `rotateX(${-tiltX * 0.5}deg) rotateY(${tiltY * 0.5}deg)`;
            });
        }, true);
    } else {
        cards.forEach(card => {
            card.addEventListener("mousemove", (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;

                card.style.transform = `rotateY(${x * 0.05}deg) rotateX(${-y * 0.05}deg) scale(1.02)`;
            });

            card.addEventListener("mouseleave", () => {
                card.style.transform = "rotateY(0deg) rotateX(0deg) scale(1)";
            });
        });
    }
});


/* ==========================================
   DIRECT WHATSAPP SHARE WITH SCORE & TEST LINK
   ========================================== */
function shareTestScore(testTitle, score, totalMarks, percentage, testId) {
    const baseUrl = window.location.origin + window.location.pathname.replace('tests.html', '');
    const testLink = `${baseUrl}take-test.html?id=${testId}`;

    const shareText = 
`🏆 *ROITX TESTHUB SCORE CARD* 🏆
--------------------------------
📝 *Test:* ${testTitle}
🎯 *Score:* ${score} / ${totalMarks}
📊 *Percentage:* ${percentage}%
--------------------------------
👉 *Aap bhi ye test attempt karke apna rank dekhein:*
${testLink}`;

    openWhatsAppFallback(shareText);
}

function openWhatsAppFallback(text) {
    const encodedText = encodeURIComponent(text);
    const waUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
    window.open(waUrl, '_blank');
}

/* ==========================================
   AUTH & MODE SELECTION MODAL HANDLING
   ========================================== */
/* Updated handleStartTest function in tests_2.js */

function handleStartTest(testId, isReattempt = false, isResume = false) {
    const userLoggedIn = isLoggedIn || localStorage.getItem("isLoggedIn") === "true";

    if (!userLoggedIn) {
        showAuthModal("Test attempt karne ke liye pehle login karein!");
        return;
    }

    pendingTestStart = { testId, isReattempt, isResume };

    // Resume case: Jump directly to take-test without prompt & reuse saved mode
    if (isResume) {
        const draft = userDraftsMap[testId];
        const savedMode = (draft && draft.mode) ? draft.mode : 'quiz';
        window.location.href = `take-test.html?id=${testId}&mode=${savedMode}&resume=true`;
        return;
    }

    openModeModal();
}


function openModeModal() {
    const modeModal = document.getElementById("modeModal");
    if (modeModal) {
        selectTestMode('quiz'); // Reset to default quiz mode
        modeModal.style.display = "flex";
    } else {
        proceedToTestWithMode();
    }
}

function closeModeModal() {
    const modeModal = document.getElementById("modeModal");
    if (modeModal) modeModal.style.display = "none";
}

function selectTestMode(mode) {
    selectedMode = mode;
    const qCard = document.getElementById("optQuizMode");
    const pCard = document.getElementById("optPracticeMode");
    const iconElem = document.getElementById("startBtnModeIcon");

    if (mode === 'quiz') {
        if (qCard) qCard.classList.add("selected");
        if (pCard) pCard.classList.remove("selected");
        if (iconElem) iconElem.className = "fa-solid fa-stopwatch";
    } else {
        if (pCard) pCard.classList.add("selected");
        if (qCard) qCard.classList.remove("selected");
        if (iconElem) iconElem.className = "fa-solid fa-book-open";
    }
}

function proceedToTestWithMode() {
    const { testId, isReattempt, isResume } = pendingTestStart;
    if (!testId) return;

    let urlParams = `id=${testId}&mode=${selectedMode}`;
    if (isReattempt) urlParams += '&reattempt=true';
    if (isResume) urlParams += '&resume=true';

    closeModeModal();
    window.location.href = `take-test.html?${urlParams}`;
}

function showAuthModal(customMessage) {
    const authModal = document.getElementById("authModal");
    if (authModal) {
        const msgElem = document.getElementById("authModalMsg");
        if (msgElem && customMessage) {
            msgElem.innerText = customMessage;
        }
        authModal.style.display = "flex";
    } else {
        alert(customMessage);
        window.location.href = "login.html";
    }
}

function closeAuthModal() {
    const modal = document.getElementById("authModal");
    if (modal) modal.style.display = "none";
}

function redirectToLogin() {
    window.location.href = "login.html";
}

/* ==========================================
   NAVIGATION & TAB SWITCHING
   ========================================== */
function switchTab(tab) {
    const testsSec = document.getElementById("testsSection");
    const leaderSec = document.getElementById("leaderboardSection");
    const tabTestsBtn = document.getElementById("tabTestsBtn");
    const tabLeaderboardBtn = document.getElementById("tabLeaderboardBtn");

    if (tab === 'tests') {
        if (testsSec) testsSec.style.display = "block";
        if (leaderSec) leaderSec.style.display = "none";
        if (tabTestsBtn) tabTestsBtn.classList.add("active");
        if (tabLeaderboardBtn) tabLeaderboardBtn.classList.remove("active");
    } else {
        const userLoggedIn = isLoggedIn || localStorage.getItem("isLoggedIn") === "true";
        if (!userLoggedIn) {
            showAuthModal("Leaderboard dekhne ke liye pehle login karein!");
            return;
        }

        if (testsSec) testsSec.style.display = "none";
        if (leaderSec) leaderSec.style.display = "block";
        if (tabTestsBtn) tabTestsBtn.classList.remove("active");
        if (tabLeaderboardBtn) tabLeaderboardBtn.classList.add("active");
        loadLeaderboardData();
    }
}

/* ==========================================
   STEP-BY-STEP LEADERBOARD FILTER SYSTEM
   ========================================== */
function toggleLeaderboardFilters() {
    const drawer = document.getElementById('leaderboardFilterDrawer');
    const chevron = document.getElementById('lbChevron');
    if (!drawer) return;

    const isHidden = drawer.style.display === 'none' || drawer.style.display === '';
    drawer.style.display = isHidden ? 'block' : 'none';
    if (chevron) chevron.className = isHidden ? 'fa-solid fa-chevron-up' : 'fa-solid fa-chevron-down';
}

function populateLeaderboardTestDropdown(tests) {
    const lbSelect = document.getElementById("leaderboardFilterTest");
    if (!lbSelect) return;

    let html = `<option value="ALL">All Tests Combined</option>`;
    tests.forEach(t => {
        html += `<option value="${t.id}">${t.title}</option>`;
    });
    lbSelect.innerHTML = html;
}

function initLeaderboardStepView() {
    renderLbBoardStep();
    
    const classBlock = document.getElementById("lbClassStepBlock");
    const subjectBlock = document.getElementById("lbSubjectStepBlock");
    const testBlock = document.getElementById("lbTestStepBlock");

    if (classBlock) classBlock.style.display = "none";
    if (subjectBlock) subjectBlock.style.display = "none";
    if (testBlock) testBlock.style.display = "none";
}

function renderLbBoardStep() {
    const boardBox = document.getElementById("lbBoardChips");
    if (!boardBox) return;

    const boards = new Set();
    studentTests.forEach(t => {
        const titleUpper = (t.title || "").toUpperCase();
        if (titleUpper.includes("BSEB") || titleUpper.includes("BIHAR")) boards.add("BSEB");
        else if (titleUpper.includes("CBSE")) boards.add("CBSE");
        else if (titleUpper.includes("NEET")) boards.add("NEET");
        else if (titleUpper.includes("JEE")) boards.add("JEE");
    });

    let html = `<button class="chip-btn ${selectedLbBoard === 'ALL' ? 'active' : ''}" onclick="selectLbBoardStep('ALL')">All Boards</button>`;
    boards.forEach(b => {
        html += `<button class="chip-btn ${selectedLbBoard === b ? 'active' : ''}" onclick="selectLbBoardStep('${b}')">${b}</button>`;
    });

    boardBox.innerHTML = html;
}

function selectLbBoardStep(b) {
    selectedLbBoard = b;
    selectedLbClass = "ALL";
    selectedLbSubject = "ALL";
    selectedLbTestId = "ALL";

    renderLbBoardStep();

    const classBlock = document.getElementById("lbClassStepBlock");
    const subjectBlock = document.getElementById("lbSubjectStepBlock");
    const testBlock = document.getElementById("lbTestStepBlock");

    if (classBlock) classBlock.style.display = "block";
    if (subjectBlock) subjectBlock.style.display = "none";
    if (testBlock) testBlock.style.display = "none";

    renderLbClassStep();
    loadLeaderboardData();
}

function renderLbClassStep() {
    const classBox = document.getElementById("lbClassChips");
    if (!classBox) return;

    const classes = new Set();
    studentTests.forEach(t => {
        const fullText = `${t.title || ''} ${t.class_level || ''}`.toUpperCase();
        
        let boardMatch = (selectedLbBoard === "ALL") || 
            (selectedLbBoard === "BSEB" && (fullText.includes("BSEB") || fullText.includes("BIHAR"))) ||
            fullText.includes(selectedLbBoard.toUpperCase());

        if (boardMatch) {
            if (t.class_level && t.class_level.trim() !== "") {
                classes.add(t.class_level.trim());
            } else if (fullText.includes("12")) classes.add("Class 12th");
            else if (fullText.includes("11")) classes.add("Class 11th");
            else if (fullText.includes("10")) classes.add("Class 10th");
        }
    });

    let html = `<button class="chip-btn ${selectedLbClass === 'ALL' ? 'active' : ''}" onclick="selectLbClassStep('ALL')">All Classes</button>`;
    classes.forEach(c => {
        html += `<button class="chip-btn ${selectedLbClass === c ? 'active' : ''}" onclick="selectLbClassStep('${c}')">${c}</button>`;
    });

    classBox.innerHTML = html;
}

function selectLbClassStep(c) {
    selectedLbClass = c;
    selectedLbSubject = "ALL";
    selectedLbTestId = "ALL";

    renderLbClassStep();

    const subjectBlock = document.getElementById("lbSubjectStepBlock");
    const testBlock = document.getElementById("lbTestStepBlock");

    if (subjectBlock) subjectBlock.style.display = "block";
    if (testBlock) testBlock.style.display = "none";

    renderLbSubjectStep();
    loadLeaderboardData();
}

function renderLbSubjectStep() {
    const subjectBox = document.getElementById("lbSubjectChips");
    if (!subjectBox) return;

    const subjects = new Set();
    studentTests.forEach(t => {
        const fullText = `${t.title || ''} ${t.class_level || ''}`.toUpperCase();
        
        let boardMatch = (selectedLbBoard === "ALL") || 
            (selectedLbBoard === "BSEB" && (fullText.includes("BSEB") || fullText.includes("BIHAR"))) ||
            fullText.includes(selectedLbBoard.toUpperCase());

        // Strict Class Matching Logic
        let tClassClean = (t.class_level || '').trim().toLowerCase();
        let selectedLbClassClean = selectedLbClass.trim().toLowerCase();

        let classMatch = (selectedLbClass === "ALL") ||
            (t.class_level && tClassClean === selectedLbClassClean) ||
            (selectedLbClassClean.includes("10") && (tClassClean.includes("10") || fullText.includes("CLASS 10") || fullText.includes("10TH")) && !tClassClean.includes("12") && !fullText.includes("12TH")) ||
            (selectedLbClassClean.includes("11") && (tClassClean.includes("11") || fullText.includes("CLASS 11") || fullText.includes("11TH"))) ||
            (selectedLbClassClean.includes("12") && (tClassClean.includes("12") || fullText.includes("CLASS 12") || fullText.includes("12TH")));

        if (boardMatch && classMatch && t.subject) {
            subjects.add(t.subject.trim());
        }
    });

    let html = `<button class="chip-btn ${selectedLbSubject === 'ALL' ? 'active' : ''}" onclick="selectLbSubjectStep('ALL')">All Subjects</button>`;
    subjects.forEach(s => {
        html += `<button class="chip-btn ${selectedLbSubject === s ? 'active' : ''}" onclick="selectLbSubjectStep('${s}')">${s}</button>`;
    });

    subjectBox.innerHTML = html;
}

function selectLbSubjectStep(s) {
    selectedLbSubject = s;
    selectedLbTestId = "ALL";

    renderLbSubjectStep();

    const testBlock = document.getElementById("lbTestStepBlock");
    if (testBlock) testBlock.style.display = "block";

    renderLbTestStep();
    loadLeaderboardData();
}

function renderLbTestStep() {
    const testBox = document.getElementById("lbTestChips");
    if (!testBox) return;

    const filteredTests = studentTests.filter(t => {
        const fullText = `${t.title || ''} ${t.class_level || ''}`.toUpperCase();

        let boardMatch = (selectedLbBoard === "ALL") || 
            (selectedLbBoard === "BSEB" && (fullText.includes("BSEB") || fullText.includes("BIHAR"))) ||
            fullText.includes(selectedLbBoard.toUpperCase());

        let tClassClean = (t.class_level || '').trim().toLowerCase();
        let selectedLbClassClean = selectedLbClass.trim().toLowerCase();

        let classMatch = (selectedLbClass === "ALL") ||
            (t.class_level && tClassClean === selectedLbClassClean) ||
            (selectedLbClassClean.includes("10") && (tClassClean.includes("10") || fullText.includes("10")) && !tClassClean.includes("12") && !fullText.includes("12")) ||
            (selectedLbClassClean.includes("11") && (tClassClean.includes("11") || fullText.includes("11"))) ||
            (selectedLbClassClean.includes("12") && (tClassClean.includes("12") || fullText.includes("12")));

        let subMatch = (selectedLbSubject === "ALL") || 
            (t.subject && t.subject.trim().toLowerCase().includes(selectedLbSubject.toLowerCase()));

        return boardMatch && classMatch && subMatch;
    });

    let html = `<button class="chip-btn ${selectedLbTestId === 'ALL' ? 'active' : ''}" onclick="selectLbTestStep('ALL')">All Tests Combined</button>`;
    filteredTests.forEach(t => {
        html += `<button class="chip-btn ${selectedLbTestId === t.id ? 'active' : ''}" onclick="selectLbTestStep('${t.id}')">${t.title}</button>`;
    });

    testBox.innerHTML = html;
}

function selectLbTestStep(testId) {
    selectedLbTestId = testId;
    renderLbTestStep();
    loadLeaderboardData();
}

function resetLeaderboardFilters() {
    selectedLbBoard = "ALL";
    selectedLbClass = "ALL";
    selectedLbSubject = "ALL";
    selectedLbTestId = "ALL";

    initLeaderboardStepView();
    loadLeaderboardData();
}

/* ==========================================
   PODIUM & LEADERBOARD FETCHING LOGIC
   ========================================== */
function renderPodiumCards(data) {
    let container = document.getElementById("podiumContainer");
    const defaultAvatar = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
    const crownSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="#f6e05e"><path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/></svg>`;
    
    if (!container) {
        console.warn("Podium container element not found in DOM!");
        return;
    }

    if (!data || data.length === 0) {
        container.innerHTML = "";
        return;
    }

    const top1 = data[0] || null;
    const top2 = data[1] || null;
    const top3 = data[2] || null;

    let html = "";

    if (top2) {
        let photo = top2.profiles?.avatar_url || defaultAvatar;
        html += `
            <div class="podium-card rank-2">
                <img src="${photo}" class="podium-avatar" alt="Rank 2" onerror="this.src='${defaultAvatar}'">
                <div class="podium-badge">2</div>
                <div class="podium-name">${top2.profiles?.full_name || 'Student'}</div>
                <div class="podium-score">${top2.score}/${top2.total_marks}</div>
            </div>
        `;
    }

    if (top1) {
        let photo = top1.profiles?.avatar_url || defaultAvatar;
        html += `
            <div class="podium-card rank-1">
                ${crownSvg}
                <img src="${photo}" class="podium-avatar" alt="Rank 1" onerror="this.src='${defaultAvatar}'">
                <div class="podium-badge">1</div>
                <div class="podium-name">${top1.profiles?.full_name || 'Student'}</div>
                <div class="podium-score">${top1.score}/${top1.total_marks}</div>
            </div>
        `;
    }

    if (top3) {
        let photo = top3.profiles?.avatar_url === "string" ? top3.profiles.avatar_url : (top3.profiles?.avatar_url || defaultAvatar);
        html += `
            <div class="podium-card rank-3">
                <img src="${photo}" class="podium-avatar" alt="Rank 3" onerror="this.src='${defaultAvatar}'">
                <div class="podium-badge">3</div>
                <div class="podium-name">${top3.profiles?.full_name || 'Student'}</div>
                <div class="podium-score">${top3.score}/${top3.total_marks}</div>
            </div>
        `;
    }

    container.innerHTML = html;
    container.style.display = "flex";
}

async function loadLeaderboardData() {
    const tbody = document.getElementById("leaderboardBody");
    const loader = document.getElementById("leaderboardLoader");

    if (loader) loader.style.display = "block";

    try {
        const { data: { user } } = await window.supabaseClient.auth.getUser();
        if (!user) {
            showAuthModal("Leaderboard dekhne ke liye pehle login karein!");
            if (loader) loader.style.display = "none";
            return;
        }

        const { data: userProfile } = await window.supabaseClient
            .from('profiles')
            .select('pincode')
            .eq('id', user.id)
            .maybeSingle();

        let currentPincode = userProfile?.pincode;

        if (!currentPincode || currentPincode.trim() === "") {
            const enteredPin = prompt("📍 Apne ilake ka Leaderboard dekhne ke liye apna 6-digit Pincode darj karein:");
            if (enteredPin && enteredPin.trim().length === 6) {
                currentPincode = enteredPin.trim();
                await window.supabaseClient
                    .from('profiles')
                    .update({ pincode: currentPincode })
                    .eq('id', user.id);
            } else {
                if (tbody) {
                    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#e53e3e; font-weight:bold; padding:20px;">⚠️ Leaderboard dekhne ke liye valid Pincode add karna zaroori hai. Page refresh karke dobara try karein.</td></tr>`;
                }
                renderPodiumCards([]);
                return;
            }
        }

        let query = window.supabaseClient
    .from('test_results')
    .select(`
        id,
        user_id,
        score,
        total_marks,
        test_id,
        created_at,
        tests!inner ( title, subject, class_level ),
        profiles!inner ( id, full_name, pincode, avatar_url, city, current_streak )
    `)
    .eq('profiles.pincode', currentPincode)
    .order('score', { ascending: false });
        if (selectedLbTestId && selectedLbTestId !== "ALL") {
            query = query.eq('test_id', selectedLbTestId);
        }

        const { data, error } = await query;
        if (error) throw error;

        let uniqueMap = {};
        (data || []).forEach(row => {
            let uniqueKey = `${row.user_id}_${row.test_id}`; 
            
            if (!uniqueMap[uniqueKey] || uniqueMap[uniqueKey].score < row.score) {
                uniqueMap[uniqueKey] = row;
            }
        });

        let processedData = Object.values(uniqueMap);
        processedData.sort((a, b) => b.score - a.score);

        // Filter Logic
        let filteredData = processedData.filter(row => {
            const testTitle = (row.tests?.title || '').toLowerCase();
            const testClass = (row.tests?.class_level || '').trim().toLowerCase();
            const testSub = (row.tests?.subject || '').trim().toLowerCase();
            const combinedText = testTitle + " " + testClass;

            const matchesBoard = (selectedLbBoard === "ALL") ||
                (selectedLbBoard === "BSEB" && (combinedText.includes("bseb") || combinedText.includes("bihar"))) ||
                combinedText.includes(selectedLbBoard.toLowerCase());

            const selectedLbClassClean = selectedLbClass.trim().toLowerCase();
            const matchesClass = (selectedLbClass === "ALL") ||
                (row.tests?.class_level && row.tests.class_level.trim().toLowerCase() === selectedLbClassClean) ||
                (selectedLbClassClean.includes("10") && (testClass.includes("10") || testTitle.includes("class 10") || testTitle.includes("10th")) && !testClass.includes("12") && !testTitle.includes("12th")) ||
                (selectedLbClassClean.includes("11") && (testClass.includes("11") || testTitle.includes("class 11") || testTitle.includes("11th"))) ||
                (selectedLbClassClean.includes("12") && (testClass.includes("12") || testTitle.includes("class 12") || testTitle.includes("12th")));

            const matchesSubject = (selectedLbSubject === "ALL") ||
                testSub.includes(selectedLbSubject.toLowerCase());

            return matchesBoard && matchesClass && matchesSubject;
        });

        renderPodiumCards(filteredData);

        // 1. User Ka Overall Rank Find Karein
        let userRankIndex = filteredData.findIndex(row => row.user_id === user.id);
        let userRank = userRankIndex !== -1 ? userRankIndex + 1 : null;
        let userData = userRankIndex !== -1 ? filteredData[userRankIndex] : null;

        // 2. Default sirf Top 10 Display honge
        const top10Data = filteredData.slice(0, 10);

        let html = "";
        const defaultAvatar = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
        const locationSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="#a0aec0" style="vertical-align: middle; margin-right: 3px;"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5-2.5z"/></svg>`;
        const crownSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="#f6e05e"><path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/></svg>`;

        top10Data.forEach((row, index) => {
    let rankDisplay = index === 0 ? crownSvg : (index === 1 ? '🥈' : (index === 2 ? '🥉' : `<span style="background:#edf2f7; color:#2d3748; padding:3px 8px; border-radius:6px; font-weight:700;">${index + 1}</span>`));
    let userPhoto = row.profiles?.avatar_url || defaultAvatar;
    let areaName = row.profiles?.city || 'Local Area';
    
    // User ka streak value (agar na ho toh default 1)
    let userStreak = row.profiles?.current_streak || 1; 

    let percentage = (row.total_marks && row.total_marks > 0) 
        ? Math.round((row.score / row.total_marks) * 100) 
        : 0;

    html += `
    <tr>
        <td><strong>${rankDisplay}</strong></td>
        <td>
            <div style="display: flex; align-items: center; gap: 8px;">
                <img src="${userPhoto}" style="width: 28px; height: 28px; border-radius: 50%; object-fit: cover; flex-shrink: 0;" onerror="this.src='${defaultAvatar}'">
                <div style="display: flex; align-items: center; gap: 6px; flex-wrap: nowrap;">
                    <b style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 90px;">${row.profiles?.full_name || 'Student'}</b>
                    <span style="font-size: 10px; background: rgba(255,183,3,0.15); color: #b45309; padding: 2px 5px; border-radius: 6px; font-weight: 700; white-space: nowrap; flex-shrink: 0;">🔥 ${userStreak}d</span>
                </div>
            </div>
        </td>
        <td>${areaName}</td>
        <td>${row.tests?.title || 'Test'}</td>
        <td><strong style="color:#007bff;">${row.score}</strong> / ${row.total_marks}</td>
    </tr>
`;

});


        if (tbody) {
            tbody.innerHTML = html || `<tr><td colspan="5" style="text-align:center; padding:20px; color:#718096;">Is filter criteria ke liye koi leaderboard entries nahi mili.</td></tr>`;
        }

        // 3. User Bottom Card Logic (Gar user rank > 10 hai to hi dikhega)
        let userRankCard = document.getElementById("currentUserRankCard");
        
        // Dynamic Card Create Karein Gar DOM me na ho
        if (!userRankCard) {
            userRankCard = document.createElement("div");
            userRankCard.id = "currentUserRankCard";
            userRankCard.className = "user-rank-card";
            const leaderSection = document.getElementById("leaderboardSection");
            if (leaderSection) leaderSection.appendChild(userRankCard);
        }

        if (userRank && userRank > 10 && userData) {
            let uPct = userData.total_marks > 0 ? Math.round((userData.score / userData.total_marks) * 100) : 0;
            userRankCard.style.display = "flex";
userRankCard.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(135deg, rgba(13, 22, 45, 0.95), rgba(8, 14, 26, 0.95));
    border: 1.5px solid rgba(0, 210, 255, 0.4);
    border-radius: 16px;
    padding: 12px 18px;
    margin-top: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6), inset 0 0 15px rgba(0, 210, 255, 0.1);
    color: #ffffff;
    position: relative;
    overflow: hidden;
`;

userRankCard.innerHTML = `
    <div style="display: flex; align-items: center; gap: 12px;">
        <div style="background: linear-gradient(135deg, #00f0ff, #3a7bd5); color: #050b18; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 13px; box-shadow: 0 0 10px rgba(0,240,255,0.5);">
            ${userRank}
        </div>
        <img src="${userData.profiles?.avatar_url || defaultAvatar}" style="width: 38px; height: 38px; border-radius: 50%; object-fit: cover; border: 1.5px solid #00f0ff;" onerror="this.src='${defaultAvatar}'">
        <div>
            <div style="font-size: 14px; font-weight: 800; color: #fff; letter-spacing: 0.3px;">You</div>
            <div style="font-size: 11px; color: #94a3b8; font-weight: 600;">${userData.profiles?.full_name || 'Student'} • 🔥 ${userData.profiles?.current_streak || 1}d</div>
        </div>
    </div>
    <div style="text-align: right;">
        <div style="font-weight: 900; font-size: 16px; background: linear-gradient(135deg, #00f0ff, #ffd700); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">${userData.score} / ${userData.total_marks}</div>
        <div style="font-size: 11px; color: #34d399; font-weight: 700;">(${uPct}% Accuracy)</div>
    </div>
`;
        } else {
            // Gar Top 10 me hai ya test nahi diya to card hide kar dein
            userRankCard.style.display = "none";
        }

    } catch (err) {
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:red;">Error loading leaderboard: ${err.message}</td></tr>`;
        }
    } finally {
        if (loader) loader.style.display = "none";
    }
}
