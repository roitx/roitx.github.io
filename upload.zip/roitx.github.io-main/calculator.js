// --- GLOBAL CALCULATOR ENGINE ---
let exp = ""; 
let cursorPos = 0; 
let isDeg = true;
let isShift = false;
let isAlpha = false;
let isHyp = false; 
let lastAnswer = "0"; 
let memory = 0; 
let historyIndex = -1;
let currentAIMode = "text"; 

// LOCAL STORAGE + SUPABASE AUTH SYNC
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true"; 

// AUTOMATIC SUPABASE SYNC ON LOAD
document.addEventListener("DOMContentLoaded", async () => {
  if (window.supabaseClient) {
    const { data: { session } } = await window.supabaseClient.auth.getSession();
    if (session && session.user) {
      isLoggedIn = true;
      localStorage.setItem("isLoggedIn", "true");
    } else {
      isLoggedIn = false;
      localStorage.removeItem("isLoggedIn");
    }

    window.supabaseClient.auth.onAuthStateChange((event, session) => {
      if (session && session.user) {
        isLoggedIn = true;
        localStorage.setItem("isLoggedIn", "true");
      } else {
        isLoggedIn = false;
        localStorage.removeItem("isLoggedIn");
      }
    });
  }
});

const exprDiv = document.getElementById("expression");
const resDiv = document.getElementById("result");
const shiftInd = document.getElementById("shiftIndicator");
const alphaInd = document.getElementById("alphaIndicator");
const degInd = document.getElementById("degIndicator");
const radInd = document.getElementById("radIndicator");

// --- CANVAS DRAWING ENGINE (pointer + size aware: works in normal and fullscreen) ---
let canvas, ctx, isDrawing = false, strokes = [], padBound = false;

function fitCanvas() {
  if (!canvas) return;
  const r = canvas.getBoundingClientRect();
  if (!r.width || !r.height) return;
  const d = window.devicePixelRatio || 1, w = Math.round(r.width * d), h = Math.round(r.height * d);
  if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  ctx = canvas.getContext("2d");
  redrawPad();
}

function redrawPad() {
  if (!ctx) return;
  const d = window.devicePixelRatio || 1;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.setTransform(d, 0, 0, d, 0, 0);
  ctx.strokeStyle = "#00ff9c"; ctx.lineWidth = 3; ctx.lineCap = "round"; ctx.lineJoin = "round";
  strokes.forEach((s) => {
    ctx.beginPath();
    s.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    if (s.length === 1) ctx.lineTo(s[0][0] + .1, s[0][1]);
    ctx.stroke();
  });
}

// pointer position in CSS pixels, relative to the canvas (independent of its internal size)
function padPoint(e) {
  const r = canvas.getBoundingClientRect();
  return [e.clientX - r.left, e.clientY - r.top];
}

function initCanvas() {
  canvas = document.getElementById("mathCanvas");
  if (!canvas) return;
  fitCanvas();
  if (padBound) return;
  padBound = true;
  canvas.addEventListener("pointerdown", (e) => {
    canvas.setPointerCapture(e.pointerId);
    isDrawing = true;
    strokes.push([padPoint(e)]);
    redrawPad();
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!isDrawing) return;
    const s = strokes[strokes.length - 1], p = padPoint(e), q = s[s.length - 1];
    s.push(p);
    ctx.beginPath(); ctx.moveTo(q[0], q[1]); ctx.lineTo(p[0], p[1]); ctx.stroke();
  });
  ["pointerup", "pointercancel", "pointerleave"].forEach((t) => canvas.addEventListener(t, () => { isDrawing = false; }));
  window.addEventListener("resize", fitCanvas);
}

function clearCanvas() { strokes = []; redrawPad(); }

function getCompressedCanvasImage() {
  if (!canvas) return null;
  const tempCanvas = document.createElement('canvas');
  const tempCtx = tempCanvas.getContext('2d');

  const maxWidth = 400;
  const scale = Math.min(1, maxWidth / canvas.width);
  tempCanvas.width = canvas.width * scale;
  tempCanvas.height = canvas.height * scale;

  tempCtx.fillStyle = "#000000";
  tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
  tempCtx.drawImage(canvas, 0, 0, tempCanvas.width, tempCanvas.height);

  return tempCanvas.toDataURL('image/jpeg', 0.5);
}

function toggleAISolverFullscreen() {
  const content = document.getElementById("aiContent");
  if (content) {
    content.classList.toggle("fullscreen");
    setTimeout(fitCanvas, 60); // re-measure the pad after the layout changes
  }
}

// HELPER FUNCTION TO SHOW AUTH POPUP WITH CUSTOM MESSAGE
function showAuthModal(customMessage) {
  const authModal = document.getElementById("authModal");
  if (authModal) {
    const modalDesc = authModal.querySelector("p") || authModal.querySelector(".modal-body");
    if (modalDesc && customMessage) {
      modalDesc.innerText = customMessage;
    }
    authModal.style.display = "flex";
  }
}

// FAST AI SOLVER WITH STRICT CLEAN OUTPUT RULES & AUTO-CLEANUP
async function submitAISolver(lang) {
  const userLoggedIn = isLoggedIn || localStorage.getItem("isLoggedIn") === "true";
  
  if (!userLoggedIn) {
    let usageCount = parseInt(localStorage.getItem("guestTextUsage") || "0", 10);
    if (usageCount >= 1) {
      showAuthModal("Unlimited messages aur full access ke liye login karein!");
      return;
    }
  }

  let loader = document.getElementById("aiLoader");
  let resBox = document.getElementById("aiResponse");
  
  if (loader) loader.style.display = "block";
  if (resBox) resBox.innerHTML = "Thinking...";

  // Direct and clean system instruction
  const systemInstruction = `Provide ONLY the direct step-by-step mathematical solution in ${lang === 'hi' ? 'Hindi' : 'English'}. Do NOT include task descriptions, constraints, rules, intro, or system messages.`;

  let userText = document.getElementById("aiPrompt")?.value.trim() || "Solve equation";
  let base64Img = null;

  if (currentAIMode !== 'text') {
    base64Img = (currentAIMode === 'pad') ? getCompressedCanvasImage() : document.getElementById("imagePreview")?.src;
  }

  const apiUrl = "https://ktastwehnnqicriknewr.supabase.co/functions/v1/smart-task";
  const apiKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt0YXN0d2Vobm5xaWNyaWtuZXdyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUyNTk5NTEsImV4cCI6MjA4MDgzNTk1MX0.5_UvwaG0X8k_Emj-cMC0KjEqlvU6hgAt5IsHJdgARvk";

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json', 
        'apikey': apiKey,
        'Authorization': `Bearer ${apiKey}` 
      },
      body: JSON.stringify({ 
        prompt: systemInstruction + "\n\nSolve: " + userText,
        language: lang, 
        image: base64Img,
        generationConfig: { max_output_tokens: 500, temperature: 0.1 }
      })
    });

    const data = await response.json();
    if (loader) loader.style.display = "none";

    let rawContent = data.choices?.[0]?.message?.content || data.result || data.response || data.output || data.message;

    if (rawContent) {
      if (typeof rawContent === 'object') rawContent = JSON.stringify(rawContent);

      // --- AUTOMATIC CLEANUP LOGIC ---
      // Step 1: Remove Task & Constraint lines
      rawContent = rawContent.replace(/^\s*\*?\s*(Task|Constraint\s*\d+|Rule\s*\d+|Instruction):.*$/gim, '');
      
      // Step 2: Remove duplicated prompt headers if generated
      rawContent = rawContent.replace(/Provide ONLY the direct.*$/gim, '');
      
      // Step 3: Trim multiple empty lines
      rawContent = rawContent.replace(/\n\s*\n+/g, '\n').trim();

      if (resBox) resBox.innerHTML = rawContent.replace(/\n/g, "<br>");
      
      if (window.MathJax) {
        MathJax.typesetPromise([resBox]);
      }

      if (!userLoggedIn && currentAIMode === 'text') {
        let currentCount = parseInt(localStorage.getItem("guestTextUsage") || "0", 10);
        localStorage.setItem("guestTextUsage", (currentCount + 1).toString());
      }
    } else {
      if (resBox) resBox.innerText = "Error: Couldn't fetch response. Please try again.";
    }
  } catch (err) {
    if (loader) loader.style.display = "none";
    if (resBox) resBox.innerText = "Network Error. Please check connection.";
  }
}


function switchAIMode(mode) {
  const userLoggedIn = isLoggedIn || localStorage.getItem("isLoggedIn") === "true";

  if ((mode === 'pad' || mode === 'scan') && !userLoggedIn) {
    showAuthModal("Draw Pad aur Scan Mode use karne ke liye login karein!");
    return;
  }

  currentAIMode = mode;
  document.getElementById("tabText")?.classList.toggle("active", mode === 'text');
  
  const tabPad = document.getElementById("tabPad");
  if (tabPad) {
    tabPad.classList.toggle("active", mode === 'pad');
    tabPad.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 4px;"><path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="M2 2l7.586 7.586"></path><circle cx="11" cy="11" r="2"></circle></svg>Draw Pad`;
  }

  const tabScan = document.getElementById("tabScan");
  if (tabScan) {
    tabScan.classList.toggle("active", mode === 'scan');
    tabScan.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 4px;"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>Scan Equation`;
  }

  if (document.getElementById("aiTextSec")) document.getElementById("aiTextSec").style.display = mode === 'text' ? 'block' : 'none';
  if (document.getElementById("aiPadSec")) document.getElementById("aiPadSec").style.display = mode === 'pad' ? 'block' : 'none';
  if (document.getElementById("aiScanSec")) document.getElementById("aiScanSec").style.display = mode === 'scan' ? 'block' : 'none';

  if (mode === 'pad') {
    setTimeout(initCanvas, 50);
  }
}

function handleImagePreview(event) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const previewImg = document.getElementById("imagePreview");
      const previewContainer = document.getElementById("imagePreviewContainer");
      if (previewImg) previewImg.src = e.target.result;
      if (previewContainer) previewContainer.style.display = "block";
    };
    reader.readAsDataURL(file);
  }
}

function openGuideModal() {
  const m = document.getElementById("guideModal");
  if (m) m.style.display = "flex";
}

function closeGuideModal() {
  const m = document.getElementById("guideModal");
  if (m) m.style.display = "none";
}

function openKeysGuide() {
  closeGuideModal();
  const keysModal = document.getElementById("keysGuideModal");
  if (keysModal) keysModal.style.display = "flex";
}

function closeKeysGuide() {
  const keysModal = document.getElementById("keysGuideModal");
  if (keysModal) keysModal.style.display = "none";
}

function closeAuthModal() {
  const modal = document.getElementById("authModal");
  if (modal) modal.style.display = "none";
}

function redirectToLogin() {
  window.location.href = "login.html";
}

window.addEventListener("click", function(e) {
  const gModal = document.getElementById("guideModal");
  const kModal = document.getElementById("keysGuideModal");
  const aModal = document.getElementById("authModal");
  
  if (e.target === gModal) gModal.style.display = "none";
  if (e.target === kModal) kModal.style.display = "none";
  if (e.target === aModal) aModal.style.display = "none";
});

function preprocess(raw) {
  let s = raw;
  s = s.replace(/Ans/g, `(${lastAnswer})`);
  s = s.replace(/π/g, "pi").replace(/e/g, "e");

  s = s.replace(/sin⁻¹\(/g, "asin(").replace(/cos⁻¹\(/g, "acos(").replace(/tan⁻¹\(/g, "atan(");
  s = s.replace(/sinh\(/g, "sinh(").replace(/cosh\(/g, "cosh(").replace(/tanh\(/g, "tanh(");
  s = s.replace(/erf\(/g, "erf(").replace(/gamma\(/g, "gamma(").replace(/zeta\(/g, "zeta(");
  s = s.replace(/lcm\(/g, "lcm(").replace(/gcd\(/g, "gcd(");
  
  s = s.replace(/(\d+)C(\d+)/g, "(factorial($1)/(factorial($2)*factorial($1-$2)))");
  s = s.replace(/(\d+)P(\d+)/g, "(factorial($1)/factorial($1-$2))");

  s = s.replace(/×/g, "*").replace(/÷/g, "/").replace(/√\(/g, "sqrt(").replace(/∛\(/g, "cbrt(");
  s = s.replace(/(\d+)²/g, "$1^2").replace(/(\d+)³/g, "$1^3");

  if (isDeg) {
    s = s.replace(/\b(sin|cos|tan|asin|acos|atan)\(([^)]+)\)/g, (match, fn, angle) => {
      if (fn.startsWith('a')) return `(${fn}(${angle}) * 180 / pi)`;
      return `${fn}((${angle}) * pi / 180)`;
    });
  }
  return s;
}

function btnPress(key) {
  if (isShift) { handleShift(key); return; }
  if (isAlpha) { handleAlpha(key); return; }

  // Agar calculation ke turant baad operator (+, -, *, /) press kiya jaye, toh Ans se start ho
  const operators = ['+', '-', '*', '/'];
  if (operators.includes(key) && exp === "" && lastAnswer !== "0") {
    exp = "Ans";
    cursorPos = 0;
  }

  const map = {
    'SIN': isHyp ? 'sinh(' : 'sin(',
    'COS': isHyp ? 'cosh(' : 'cos(',
    'TAN': isHyp ? 'tanh(' : 'tan(',
    'LOG': 'log10(', 'LN': 'log(', 'SQRT': '√(', 
    'X2': '²', 'X3': '³', 'POW': '^', 'PI': 'π', 
    'NCR': 'C', 'ANS': 'Ans', 'MOD': '%', 'EXP': 'e',
    'ABS': 'abs(', 'HYP': 'hyp', 'COMMA': ',',
    'LCM': 'lcm(', 'RND': 'random()'
  };

  if (key === 'HYP') { isHyp = true; return; }
  if (key === 'M+') { handleMemory(1); return; }

  let val = map[key] || key;
  insertAtCursor(val);
  if (val.endsWith('(')) { insertAtCursor(")"); cursorPos++; }
  isHyp = false; 
  updateDisplay();
}

function handleShift(key) {
  const sMap = {
    'SIN': 'sin⁻¹(', 'COS': 'cos⁻¹(', 'TAN': 'tan⁻¹(',
    'SQRT': '∛(', 'LOG': '10^(', 'LN': 'e^(', 
    'X2': '!', 'X3': '^-1', 'POW': '^(1/', 'NCR': 'P', 
    'POL': 'Rec(', 'PI': 'e', 'M+': 'M-', 'ABS': 'erf(',
    'HYP': 'gamma(', 'COMMA': 'zeta(', 'LCM': 'gcd(', 'MOD': 'mod('
  };
  
  if (key === 'M+') { handleMemory(-1); } 
  else if (sMap[key]) {
    let val = sMap[key];
    insertAtCursor(val);
    if (val.endsWith('(')) { insertAtCursor(")"); cursorPos++; }
  }
  toggleShift(); 
  updateDisplay();
}

function handleAlpha(key) {
  const aMap = {
    '7': 'A', '8': 'B', '9': 'C',
    '4': 'D', '5': 'E', '6': 'F',
    '1': 'X', '2': 'Y', '3': 'M',
    'RND': 'rand()'
  };
  if (aMap[key]) insertAtCursor(aMap[key]);
  toggleAlpha(); 
  updateDisplay();
}

function toggleShift() { isShift = !isShift; if (isShift) isAlpha = false; updateIndicators(); }
function toggleAlpha() { isAlpha = !isAlpha; if (isAlpha) isShift = false; updateIndicators(); }

function updateIndicators() { 
  if (shiftInd) shiftInd.classList.toggle("active", isShift); 
  if (alphaInd) alphaInd.classList.toggle("active", isAlpha); 
  document.body.classList.toggle("shift-mode-active", isShift);
  document.body.classList.toggle("alpha-mode-active", isAlpha);
}

function toggleDegRad() { 
  isDeg = !isDeg; 
  if (degInd) degInd.classList.toggle("active", isDeg);
  if (radInd) radInd.classList.toggle("active", !isDeg);
}

function updateDisplay() {
  if (!exprDiv) return;
  exprDiv.innerHTML = ""; 
  let pos = exp.length - cursorPos;
  let textBefore = document.createTextNode(exp.slice(0, pos));
  let textAfter = document.createTextNode(exp.slice(pos));
  let cursorSpan = document.createElement("span");
  cursorSpan.className = "cursor";

  exprDiv.appendChild(textBefore);
  exprDiv.appendChild(cursorSpan);
  exprDiv.appendChild(textAfter);
}

function insertAtCursor(v) {
  let pos = exp.length - cursorPos;
  exp = exp.slice(0, pos) + v + exp.slice(pos);
  updateDisplay();
}

function calculate() {
  if (exp === "") return;
  try {
    let cleanExp = preprocess(exp);
    let raw = math.evaluate(cleanExp);
    if (typeof raw === 'object' && raw.entries) raw = raw.entries[0];
    if (!isFinite(raw)) throw new Error("Math ERROR");
    
    let result = formatFinal(raw);
    if (resDiv) resDiv.innerText = result;
    lastAnswer = result.toString();
    saveHistory(exp + "=" + result);
    
    exp = ""; cursorPos = 0; updateDisplay();
  } catch (e) {
    if (resDiv) resDiv.innerText = "Math ERROR";
  }
}

function formatFinal(num) {
  if (Math.abs(num) > 1e12 || (Math.abs(num) < 1e-7 && num !== 0)) return num.toExponential(5);
  return Number.isInteger(num) ? num : parseFloat(num.toFixed(10));
}

function openAISolver() {
  const modal = document.getElementById("aiModal");
  if (modal) modal.style.display = "flex";
  
  const aiHeaderTitle = document.querySelector("#aiModal .ai-header h3");
  if (aiHeaderTitle) {
    aiHeaderTitle.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00e676" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 6px;"><rect x="3" y="11" width="18" height="10" rx="2"></rect><circle cx="12" cy="5" r="2"></circle><path d="M12 7v4"></path><line x1="8" y1="16" x2="8" y2="16"></line><line x1="16" y1="16" x2="16" y2="16"></line></svg> ROITX AI Math Solver`;
  }

  const tabText = document.getElementById("tabText");
  if (tabText) {
    tabText.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 4px;"><polyline points="4 7 4 4 20 4 20 7"></polyline><line x1="9" y1="20" x2="15" y2="20"></line><line x1="12" y1="4" x2="12" y2="20"></line></svg>Text`;
  }
  
  const tabPad = document.getElementById("tabPad");
  if (tabPad) {
    tabPad.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 4px;"><path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="M2 2l7.586 7.586"></path><circle cx="11" cy="11" r="2"></circle></svg>Draw Pad`;
  }

  const tabScan = document.getElementById("tabScan");
  if (tabScan) {
    tabScan.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 4px;"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>Scan Equation`;
  }

  const fileUploadLabel = document.querySelector(".custom-file-upload");
  if (fileUploadLabel) {
    fileUploadLabel.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 6px;"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>Take Photo / Choose File`;
  }

  const noticeTag = document.querySelector(".notice-tag");
  if (noticeTag) {
    noticeTag.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 4px;"><path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path></svg>Draw equation below:`;
  }

  switchAIMode('text');
}

function closeAISolver() {
  const modal = document.getElementById("aiModal");
  if (modal) modal.style.display = "none";
}

function changeTheme(themeClass) { document.body.className = themeClass; updateIndicators(); }

function handleMemory(dir) {
  try {
    memory += (math.evaluate(preprocess(exp || (resDiv ? resDiv.innerText : "0"))) * dir);
    if (resDiv) resDiv.innerText = "M=" + formatFinal(memory);
    exp = ""; updateDisplay();
  } catch(e) { if (resDiv) resDiv.innerText = "Error"; }
}

function navigateHistory(dir) {
  let hist = JSON.parse(localStorage.getItem("calcHistory")) || [];
  if (hist.length === 0) return;
  historyIndex = Math.min(Math.max(-1, historyIndex + dir), hist.length - 1);
  if (historyIndex === -1) { clearAll(); return; }
  exp = hist[hist.length - 1 - historyIndex].split('=')[0];
  cursorPos = 0;
  if (resDiv) resDiv.innerText = "HIST " + (historyIndex + 1);
  updateDisplay();
}

function moveCursor(dir) {
  if (dir === -1 && (exp.length - cursorPos) > 0) cursorPos++;
  else if (dir === 1 && cursorPos > 0) cursorPos--;
  updateDisplay();
}

function del() { 
  let idx = exp.length - cursorPos;
  if(idx > 0) exp = exp.slice(0, idx - 1) + exp.slice(idx);
  updateDisplay(); 
}

function clearAll() { exp = ""; cursorPos = 0; if (resDiv) resDiv.innerText = "0"; updateDisplay(); }

function saveHistory(t) {
  let h = JSON.parse(localStorage.getItem("calcHistory")) || [];
  h.push(t); if(h.length > 20) h.shift();
  localStorage.setItem("calcHistory", JSON.stringify(h));
}

function powerOn() {
  if (exprDiv) exprDiv.innerHTML = "";
  if (resDiv) resDiv.innerText = "ROITX SCIENTIFIC";
  isShift = false; isAlpha = false;
  updateIndicators();
  setTimeout(() => {
    if (resDiv) resDiv.innerText = "fx-350MS PRO";
    setTimeout(() => {
      exp = ""; cursorPos = 0;
      if (resDiv) resDiv.innerText = "0";
      updateDisplay();
    }, 500);
  }, 500);
}

powerOn();
