/* Updated testscript.js with Strict Palette Color Matching, Skipped Filter & Card Layout Sync */

let currentTest = null, questions = [], currentIndex = 0;
let userAnswers = {}, reviewStatus = {}, skippedQuestions = {};
let currentPaletteView = 'grid';
let currentResultPaletteView = 'grid';
let timerInterval = null, isTimerPaused = false;
let totalTimeLimitSec = 0, timeRemaining = 0, totalTimeSpentSec = 0;
let currentFilter = 'all';
let currentMode = 'quiz'; 
let currentAnalysisFilter = 'all';
let currentUserProfile = null;
let isSubmitted = false;

let selectedPracticeOptions = {}; 
let practiceRevealed = {}; 

let chartBrief = null, chartAccuracy = null, chartScore = null;
function updateLegendCounts() {
    let attempted = 0;
    let skipped = 0;
    let review = 0;
    let attRev = 0;
    let skipRev = 0;

    questions.forEach((q, idx) => {
        const isAnswered = userAnswers[idx] !== undefined;
        const isReview = !!reviewStatus[idx];
        const isExplicitSkipped = !!skippedQuestions[idx];

        if (isAnswered && isReview) {
            attRev++;
        } else if (!isAnswered && isReview) {
            skipRev++;
        } else if (isReview) {
            review++;
        } else if (isAnswered) {
            attempted++;
        } else {
            skipped++;
        }
    });

    if (document.getElementById('legendAttempted')) document.getElementById('legendAttempted').innerText = attempted;
    if (document.getElementById('legendSkipped')) document.getElementById('legendSkipped').innerText = skipped;
    if (document.getElementById('legendReview')) document.getElementById('legendReview').innerText = review;
    if (document.getElementById('legendAttRev')) document.getElementById('legendAttRev').innerText = attRev;
    if (document.getElementById('legendSkipRev')) document.getElementById('legendSkipRev').innerText = skipRev;
}

// MathJax Configuration
window.MathJax = {
    tex: { inlineMath: [['$', '$'], ['\\(', '\\)']], displayMath: [['$$', '$$'], ['\\[', '\\]']] },
    chtml: { displayAlign: 'left', matchFontHeight: false },
    options: { enableMenu: false }
};

function renderMathJax(elements) {
    if (window.MathJax && typeof window.MathJax.typesetPromise === 'function') {
        window.MathJax.typesetPromise(elements).catch((err) => console.warn('MathJax Typeset Error:', err));
    }
}

function ensureMathDelimiter(str) {
    if (!str) return "";
    let trimmed = String(str).trim();
    if (trimmed.includes("\\") && !trimmed.includes("$")) return `$${trimmed}$`;
    return str;
}

function formatSolutionText(text) {
    if (!text) return "";
    let formatted = String(text);
    formatted = formatted.replace(/\s*([I|V|X]+\.\s*)/g, '<br>$1');
    formatted = formatted.replace(/\s*(\d+\.\s*)/g, '<br>$1');
    formatted = formatted.replace(/\n/g, '<br>');
    if (formatted.startsWith('<br>')) formatted = formatted.substring(4);
    return formatted;
}

function getDiagramHtml(q) {
    if (!q) return "";
    let figureHtml = "";
    if (q.diagram_svg && typeof q.diagram_svg === 'string' && q.diagram_svg.trim() !== "") {
        figureHtml = `<div style="margin: 10px 0; text-align: center; background: rgba(255,255,255,0.02); padding: 8px; border-radius: 6px; border: 1px dashed rgba(255,255,255,0.2); overflow-x: auto;">${q.diagram_svg}</div>`;
    } else if (q.image_url && q.image_url !== null) {
        figureHtml = `<div style="margin: 8px 0; text-align: center;"><img src="${q.image_url}" alt="Question Figure" style="max-width: 100%; max-height: 220px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.15);" onError="this.style.display='none';"></div>`;
    }
    return figureHtml;
}

function preventDoubleTapZoom() {
    let lastTouchEnd = 0;
    document.addEventListener('touchend', function (event) {
        const now = (new Date()).getTime();
        if (now - lastTouchEnd <= 300) {
            if (event.cancelable) event.preventDefault();
        }
        lastTouchEnd = now;
    }, { passive: false });
}

function initTheme() {
    const savedTheme = localStorage.getItem('theme_preference') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = savedTheme === 'light' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme_preference', newTheme);
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = newTheme === 'light' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}

function setupNetworkMonitor() {
    const banner = document.getElementById('offlineBanner');
    function updateOnlineStatus() {
        if (banner) banner.style.display = navigator.onLine ? 'none' : 'block';
    }
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();
}

function setupKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
        if (isSubmitted || (document.getElementById('testArea') && document.getElementById('testArea').style.display === 'none')) return;
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            navigateQuestion(-1);
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            handleNextOrSubmit();
        }
    });
}

window.addEventListener('DOMContentLoaded', async function() {
    preventDoubleTapZoom();
    initTheme();
    setupNetworkMonitor();
    setupKeyboardNavigation();
    await fetchUserProfile();

    const urlParams = new URLSearchParams(window.location.search);
    const testId = urlParams.get('id') || urlParams.get('testid');
    const urlMode = urlParams.get('mode');

    if (urlMode === 'practice' || urlMode === 'quiz') {
        currentMode = urlMode;
    }

    if (testId) { await loadTestDetails(testId); } 
    else { loadDummyTest(); }
});

async function fetchUserProfile() {
    if (!window.supabaseClient) return;
    try {
        const { data: { user } } = await window.supabaseClient.auth.getUser();
        if (user) {
            const { data } = await window.supabaseClient.from('profiles').select('*').eq('id', user.id).maybeSingle();
            if (data) currentUserProfile = data;
        }
    } catch (e) {
        console.warn("Could not fetch user profile:", e);
    }
}

function getDraftStorageKey() {
    return currentTest ? `test_draft_${currentTest.id}` : 'test_draft_demo';
}

async function saveProgressToSupabase(draftData) {
    if (isSubmitted || !window.supabaseClient || !currentTest || currentTest.id === 'demo_test') return;
    try {
        const { data: { user } } = await window.supabaseClient.auth.getUser();
        if (!user || isSubmitted) return;

        await window.supabaseClient
            .from('test_progress')
            .upsert({
                user_id: user.id,
                test_id: currentTest.id,
                mode: currentMode,
                user_answers: draftData.userAnswers,
                review_status: draftData.reviewStatus,
                skipped_status: draftData.skippedQuestions,
                time_remaining: draftData.timeRemaining,
                total_time_spent_sec: draftData.totalTimeSpentSec,
                is_completed: false,
                updated_at: new Date().toISOString()
            }, { onConflict: 'user_id,test_id' });
    } catch (e) {
        console.warn("Error saving progress to Supabase:", e);
    }
}

function saveLocalDraft() {
    if (isSubmitted || !currentTest) return;
    const draftData = {
        testId: currentTest.id,
        mode: currentMode,
        currentIndex: currentIndex, // <-- Bas ye line add karni hai
        userAnswers: userAnswers,
        reviewStatus: reviewStatus,
        skippedQuestions: skippedQuestions,
        timeRemaining: timeRemaining,
        totalTimeSpentSec: totalTimeSpentSec,
        lastUpdated: new Date().toISOString()
    };
    
    localStorage.setItem(getDraftStorageKey(), JSON.stringify(draftData));
    saveProgressToSupabase(draftData);
}

async function loadLocalDraft() {
    if (!currentTest) return false;

    // 1. Supabase Cloud Sync
    if (window.supabaseClient && currentTest.id !== 'demo_test') {
        try {
            const { data: { user } } = await window.supabaseClient.auth.getUser();
            if (user) {
                const { data, error } = await window.supabaseClient
                    .from('test_progress')
                    .select('*')
                    .eq('user_id', user.id)
                    .eq('test_id', currentTest.id)
                    .maybeSingle();

                if (!error && data) {
                    if (data.is_completed) {
                        clearLocalDraftStorageOnly();
                        return false; 
                    }
                    if (data.mode) currentMode = data.mode;
                    userAnswers = data.user_answers || {};
                    reviewStatus = data.review_status || {};
                    skippedQuestions = data.skipped_status || {};
                    
                    if (data.current_index !== undefined && data.current_index !== null) {
                        currentIndex = parseInt(data.current_index, 10);
                    }
                    
                    timeRemaining = data.time_remaining !== undefined ? data.time_remaining : totalTimeLimitSec;
                    totalTimeSpentSec = data.total_time_spent_sec || 0;
                    
                    Object.keys(userAnswers).forEach(idx => {
                        practiceRevealed[idx] = true;
                    });
                    return true;
                }
            }
        } catch (e) {
            console.warn("Could not load progress from Supabase:", e);
        }
    }

    // 2. LocalStorage Sync
    const key = getDraftStorageKey();
    const raw = localStorage.getItem(key);
    if (raw) {
        try {
            const draft = JSON.parse(raw);
            if (draft.mode) currentMode = draft.mode;
            userAnswers = draft.userAnswers || {};
            reviewStatus = draft.reviewStatus || {};
            skippedQuestions = draft.skippedQuestions || {};
            
            if (draft.currentIndex !== undefined && draft.currentIndex !== null) {
                currentIndex = parseInt(draft.currentIndex, 10);
            }
            
            timeRemaining = draft.timeRemaining !== undefined ? draft.timeRemaining : totalTimeLimitSec;
            totalTimeSpentSec = draft.totalTimeSpentSec || 0;
            
            Object.keys(userAnswers).forEach(idx => {
                practiceRevealed[idx] = true;
            });
            return true;
        } catch (e) {
            console.warn("Invalid draft format:", e);
        }
    }
    return false;
}

function clearLocalDraftStorageOnly() {
    if (!currentTest) return;
    const key = getDraftStorageKey();
    localStorage.removeItem(key);

    for (let i = localStorage.length - 1; i >= 0; i--) {
        const k = localStorage.key(i);
        if (k && k.includes(currentTest.id)) {
            localStorage.removeItem(k);
        }
    }
}

async function clearLocalDraft() {
    clearLocalDraftStorageOnly();

    if (window.supabaseClient && currentTest && currentTest.id !== 'demo_test') {
        try {
            const { data: { user } } = await window.supabaseClient.auth.getUser();
            if (user) {
                await window.supabaseClient
                    .from('test_progress')
                    .delete()
                    .eq('user_id', user.id)
                    .eq('test_id', currentTest.id);
            }
        } catch (e) {
            console.warn("Error clearing cloud progress:", e);
        }
    }
}

function loadDummyTest() {
    currentTest = {
        id: "demo_test",
        title: "Mathematics: Integration Quiz",
        time_limit_mins: 20,
        marks_per_question: 3,
        negative_marks: 1,
        mode: "quiz",
        questions_data: Array.from({ length: 15 }, (_, i) => ({
            question_text: `खण्डशः समाकलन (Integration by parts) विधि से $\\int x e^x dx$ का मान क्या होगा?`,
            image_url: null,
            diagram_svg: null,
            options: [
                "$e^x(x-1) + C$", 
                "$e^x(x+1) + C$", 
                "$x e^x + C$", 
                "$e^x(1-x) + C$"
            ],
            correct_option: 0,
            explanation: "I. ILATE नियम का उपयोग करते हुए:\nII. मान रखने पर:\nIII. $\\int x e^x dx = x e^x - \\int e^x dx$\nIV. अतः उत्तर $e^x(x-1) + C$ है।"
        }))
    };
    setupTestInit();
}

async function loadTestDetails(id) {
    try {
        if (!window.supabaseClient) throw new Error("Supabase client not initialized");
        const { data, error } = await window.supabaseClient.from('tests').select('*').eq('id', id).single();
        if (error || !data) throw error;
        currentTest = data;
        await setupTestInit();
    } catch (err) {
        console.error("Failed to load test details from database:", err);
        loadDummyTest();
    }
}

function setupInstructionAgreementUI(isResume) {
    const startBtn = document.getElementById("startTestBtn");
    let agreementBox = document.getElementById("instructionAgreementBox");
    const container = document.getElementById("instructionAgreementBoxContainer");
    
    if (!agreementBox && container) {
        agreementBox = document.createElement("div");
        agreementBox.id = "instructionAgreementBox";
        agreementBox.className = "inst-agreement-box";

        agreementBox.innerHTML = `
          <div class="agree-box">
            <label class="cb">
              <input type="checkbox" id="agreeInstructions">
              <span class="box">
                <svg viewBox="0 0 12 10" class="tick"><path d="M1 5 L4.5 8.5 L11 1" /></svg>
              </span>
            </label>
            <label for="agreeInstructions" class="txt">Maine sabhi instructions dhyaan se padh liye hain aur main test start karne ke liye tayar hoon.</label>
          </div>
        `;

        container.appendChild(agreementBox);

        const checkbox = document.getElementById("agreeInstructions");
        checkbox.addEventListener("change", function() {
            if (startBtn && !startBtn.getAttribute('data-loading')) {
                startBtn.disabled = !this.checked;
            }
            if (this.checked) {
                agreementBox.classList.add("checked");
            } else {
                agreementBox.classList.remove("checked");
            }
        });
    }

    const checkbox = document.getElementById("agreeInstructions");
    if (isResume) {
        if (agreementBox) agreementBox.style.display = "none";
        if (checkbox) checkbox.checked = true;
        if (startBtn) startBtn.disabled = false;
    } else {
        if (agreementBox) agreementBox.style.display = "flex";
        if (checkbox) checkbox.checked = false;
        if (startBtn) startBtn.disabled = true; // Button disabled & feeka dikhega
        if (agreementBox) agreementBox.classList.remove("checked");
   }
  }
  
async function setupTestInit() {
    isSubmitted = false;
    trackTestActivity();
    const resArea = document.getElementById("resultArea");
    if (resArea) resArea.style.display = "none";

    const btnStart = document.getElementById("startTestBtn");
    if (btnStart) {
        btnStart.disabled = true;
        btnStart.setAttribute('data-loading', 'true');
        btnStart.innerText = "Loading details...";
    }

    const instDuration = document.getElementById("instDuration");
    if (instDuration) instDuration.innerText = "-- Mins";

    const urlParams = new URLSearchParams(window.location.search);
    const urlMode = urlParams.get('mode');
    const isReattempt = urlParams.get('reattempt') === 'true';
    const isResumeParam = urlParams.get('resume') === 'true';
    let isResumeMode = false;

    if (isReattempt) {
        await clearLocalDraft();
        userAnswers = {};
        reviewStatus = {};
        skippedQuestions = {};
        selectedPracticeOptions = {};
        practiceRevealed = {};
        currentIndex = 0;
        if (urlMode) currentMode = urlMode;
        timeRemaining = totalTimeLimitSec;
        totalTimeSpentSec = 0;
    } else {
        const draftLoaded = await loadLocalDraft();
        if (draftLoaded) {
            isResumeMode = true;
        } else if (urlMode) {
            currentMode = urlMode;
        }
    }

    questions = currentTest.questions_data || [];
    const headingElem = document.getElementById("testHeading");
    if (headingElem) headingElem.innerText = currentTest.title || "Portal Test";
    
    let mins = Number(currentTest.time_limit_mins) || 20;
    totalTimeLimitSec = mins * 60;
    if (!isResumeMode) timeRemaining = totalTimeLimitSec;

    const modeSelector = document.getElementById('modeSelector');
    if (modeSelector) modeSelector.value = currentMode;

    // Resume flow: Instruction modal bypass & Jump to saved question index
    if (isResumeMode || isResumeParam) {
        const instModal = document.getElementById("instructionsModal");
        if (instModal) instModal.style.display = "none";
        startTestFromInstructions();
        return;
    }

    // Modal UI Updates (Positive/Negative Marks & Duration)
    const posMarks = currentTest.marks_per_question !== undefined ? Number(currentTest.marks_per_question) : 1;
    const negMarks = currentTest.negative_marks !== undefined ? Number(currentTest.negative_marks) : (Number(currentTest.negative_marking) || 0);
    const totalMaxMarks = questions.length * posMarks;

    if (instDuration) instDuration.innerText = `${mins} Mins`;
    
    const instMarks = document.getElementById("instMarks");
    if (instMarks) instMarks.innerText = totalMaxMarks;
    
    const instTotalQ = document.getElementById("instTotalQ");
    if (instTotalQ) instTotalQ.innerText = questions.length;
    
    const instTimeText = document.getElementById("instTimeText");
    if (instTimeText) instTimeText.innerText = `${mins} minutes`;

    const posMarkElem = document.getElementById("instPositiveMarkText");
    if (posMarkElem) {
        posMarkElem.innerText = `+${posMarks} mark${posMarks > 1 ? 's' : ''}`;
    }

    const negRuleElem = document.getElementById("instNegativeMarkingRule") || document.getElementById("instNegativeMarkRule");
    if (negRuleElem) {
        if (negMarks > 0) {
            negRuleElem.innerText = `-${negMarks} mark${negMarks > 1 ? 's' : ''}`;
            negRuleElem.style.color = "#f43f5e";
        } else {
            negRuleElem.innerText = "No negative marking";
            negRuleElem.style.color = "#10b981";
        }
    }

    setupInstructionAgreementUI(false);

    if (btnStart) {
        btnStart.removeAttribute('data-loading');
        btnStart.innerText = "Start Test";
        const checkbox = document.getElementById("agreeInstructions");
        btnStart.disabled = !(checkbox && checkbox.checked);
    }

    const instModal = document.getElementById("instructionsModal");
    if (instModal) instModal.style.display = "flex";
}

function startTestFromInstructions() {
    const instModal = document.getElementById("instructionsModal");
    if (instModal) instModal.style.display = "none";
    
    const resArea = document.getElementById("resultArea");
    if (resArea) resArea.style.display = "none";

    const tArea = document.getElementById("testArea");
    if (tArea) tArea.style.display = "grid";

    applyModeUI();
    renderPalette();
    switchPaletteView(currentPaletteView);
    
    // 👇 Ensure stored currentIndex is loaded directly (e.g. Question 5)
    let resumeQIndex = (typeof currentIndex === 'number' && currentIndex < questions.length) ? currentIndex : 0;
    loadQuestion(resumeQIndex);
}

function exitExam() { 
    if (!isSubmitted) saveLocalDraft();
    window.location.href = "tests.html"; 
}

function onModeChange(newMode) {
    currentMode = newMode;
    applyModeUI();
    saveLocalDraft();
    loadQuestion(currentIndex);
}

function applyModeUI() {
    const modeBadge = document.getElementById('modeBadge');
    const clearBtn = document.getElementById('clearBtn');

    if (currentMode === 'practice') {
        if (modeBadge) modeBadge.innerHTML = `<i class="fa-solid fa-book-open"></i> Practice Mode`;
        if (clearBtn) clearBtn.style.display = 'none';
    } else {
        if (modeBadge) modeBadge.innerHTML = `<i class="fa-solid fa-shield-halved"></i> Quiz Mode`;
        if (clearBtn) clearBtn.style.display = 'inline-flex';
    }
    startTimer();
}

function toggleMobilePalette() {
    const box = document.getElementById("paletteBox");
    const backdrop = document.getElementById("drawerBackdrop");
    if (!box || !backdrop) return;
    if (box.classList.contains("open")) closeMobilePalette();
    else { box.classList.add("open"); backdrop.classList.add("active"); }
}

function closeMobilePalette() {
    const box = document.getElementById("paletteBox");
    const backdrop = document.getElementById("drawerBackdrop");
    if (box) box.classList.remove("open");
    if (backdrop) backdrop.classList.remove("active");
}

function switchPaletteView(view) {
    currentPaletteView = view;
    const gridEl = document.getElementById("paletteGrid");
    const listEl = document.getElementById("paletteList");
    const btnGrid = document.getElementById("btnGridView");
    const btnList = document.getElementById("btnListView");

    if (!gridEl || !listEl) return;

    if (view === 'grid') {
        gridEl.style.display = "grid";
        listEl.style.display = "none";
        if (btnGrid) btnGrid.classList.add("active");
        if (btnList) btnList.classList.remove("active");
    } else {
        gridEl.style.display = "none";
        listEl.style.display = "flex";
        if (btnList) btnList.classList.add("active");
        if (btnGrid) btnGrid.classList.remove("active");
    }
}

function switchResultPaletteView(view) {
    currentResultPaletteView = view;
    const gridEl = document.getElementById("analysisQGrid");
    const listEl = document.getElementById("analysisQList");
    const btnGrid = document.getElementById("btnResGridView");
    const btnList = document.getElementById("btnResListView");

    if (!gridEl || !listEl) return;

    if (view === 'grid') {
        gridEl.style.display = "grid";
        listEl.style.display = "none";
        if (btnGrid) btnGrid.classList.add("active");
        if (btnList) btnList.classList.remove("active");
    } else {
        gridEl.style.display = "none";
        listEl.style.display = "flex";
        if (btnList) btnList.classList.add("active");
        if (btnGrid) btnGrid.classList.remove("active");
    }
}

function getQuestionClass(idx) {
    let cls = "";
    if (idx === currentIndex) cls += " active";
    
    const isAnswered = userAnswers[idx] !== undefined;
    const isReview = !!reviewStatus[idx];
    const isSkippedExplicitly = !!skippedQuestions[idx];

    if (isAnswered && isReview) {
        return cls + " attempted-review";
    } else if (!isAnswered && isReview) {
        return cls + " skipped-review";
    } else if (isReview) {
        return cls + " review-only";
    } else if (isAnswered) {
        return cls + " answered";
    } else if (isSkippedExplicitly) {
        return cls + " explicit-skipped";
    }
    return cls + " unanswered";
}

/* RENDER PALETTE IN GRID AND LIST VIEWS WITH COMPLETE COLOR SYNC */
function renderPalette() {
    const grid = document.getElementById("paletteGrid");
    const list = document.getElementById("paletteList");
    if (!grid || !list) return;

    grid.innerHTML = "";
    list.innerHTML = "";

    questions.forEach((q, idx) => {
        const isAnswered = userAnswers[idx] !== undefined;
        const isReview = !!reviewStatus[idx];
        const isExplicitSkipped = !!skippedQuestions[idx];

        if (currentFilter === 'answered' && !isAnswered) return;
        if (currentFilter === 'skipped' && !isExplicitSkipped) return;
        if (currentFilter === 'review' && !isReview) return;

        const qClass = getQuestionClass(idx);
        const qText = q.question_text || q.question || `Question ${idx + 1}`;

        // Grid View Item
        const btn = document.createElement("button");
        btn.className = `p-btn ${qClass}`;
        btn.innerText = idx + 1;
        btn.onclick = () => { loadQuestion(idx); closeMobilePalette(); };
        grid.appendChild(btn);

        // List View Item
        const listCard = document.createElement("div");
        listCard.className = `p-list-card ${qClass}`;
        
        let statusBadge = `<span class="p-list-badge unans">Unanswered</span>`;
        if (isAnswered && isReview) statusBadge = `<span class="p-list-badge rev">Ans & Review</span>`;
        else if (!isAnswered && isReview) statusBadge = `<span class="p-list-badge rev">Skip & Review</span>`;
        else if (isAnswered) statusBadge = `<span class="p-list-badge ans">Answered</span>`;
        else if (isReview) statusBadge = `<span class="p-list-badge rev">Review</span>`;
        else if (isExplicitSkipped) statusBadge = `<span class="p-list-badge skp">Skipped</span>`;

        listCard.innerHTML = `
            <div class="p-list-head">
                <span class="p-list-num">Q${idx + 1}.</span>
                ${statusBadge}
            </div>
            <div class="p-list-text">${qText}</div>
        `;
        listCard.onclick = () => { loadQuestion(idx); closeMobilePalette(); };
        list.appendChild(listCard);
    });
    
    // 👇 Bas yeh wali line yahan add karni hai!
    updateLegendCounts();

    renderMathJax();
}


function filterPalette(filter, el) {
    currentFilter = filter;
    document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
    if (el) el.classList.add('active');
    renderPalette();
}

function loadQuestion(idx) {
    if (idx < 0 || idx >= questions.length) return;
    currentIndex = idx;

    if (currentMode === 'practice') {
        isTimerPaused = (userAnswers[currentIndex] !== undefined);
    }

    const q = questions[idx];

    const curNum = document.getElementById("currentQNum");
    if (curNum) curNum.innerText = `Question ${idx + 1}`;

    const qTextElem = document.getElementById("questionText");
    if (qTextElem) {
        let questionContent = ensureMathDelimiter(q.question_text || q.question || '');
        let diagramContent = getDiagramHtml(q);
        qTextElem.innerHTML = `${questionContent} ${diagramContent}`;
    }

    const optionsBox = document.getElementById("optionsContainer");
    if (optionsBox) optionsBox.innerHTML = "";

    const options = q.options || [q.option1, q.option2, q.option3, q.option4];
    const userSelected = userAnswers[idx];
    const tempSelected = selectedPracticeOptions[idx];
    const isRevealed = practiceRevealed[idx];
    const correctIdx = parseCorrectOption(q);
    const explanationBox = document.getElementById("practiceExplanation");

    if (optionsBox) {
        options.forEach((opt, oIdx) => {
            const card = document.createElement("div");
            let cardClasses = `option-card`;

            if (currentMode === 'practice') {
                if (isRevealed) {
                    cardClasses += ' locked';
                    if (oIdx === correctIdx) cardClasses += ' practice-correct';
                    else if (oIdx === userSelected) cardClasses += ' practice-incorrect';
                } else if (tempSelected === oIdx) {
                    cardClasses += ' selected';
                }
            } else {
                if (userSelected === oIdx) cardClasses += ' selected';
            }

            card.className = cardClasses;
            card.onclick = () => selectOption(oIdx);
            card.innerHTML = `<div class="opt-prefix">${String.fromCharCode(65 + oIdx)}</div><div>${ensureMathDelimiter(opt)}</div>`;
            optionsBox.appendChild(card);
        });

        if (currentMode === 'practice' && !isRevealed) {
            const checkBtnContainer = document.createElement("div");
            checkBtnContainer.style.marginTop = "12px";
            checkBtnContainer.style.textAlign = "right";

            const checkBtn = document.createElement("button");
            checkBtn.className = "btn btn-primary";
            checkBtn.style.padding = "8px 16px";
            checkBtn.style.fontSize = "13px";
            checkBtn.innerHTML = `<i class="fa-solid fa-circle-check"></i> Check Answer`;
            checkBtn.disabled = tempSelected === undefined;
            checkBtn.style.opacity = tempSelected === undefined ? "0.5" : "1";
            checkBtn.style.cursor = tempSelected === undefined ? "not-allowed" : "pointer";

            checkBtn.onclick = () => revealPracticeAnswer();
            checkBtnContainer.appendChild(checkBtn);
            optionsBox.appendChild(checkBtnContainer);
        }
    }

    if (explanationBox) {
        if (currentMode === 'practice' && isRevealed) {
            explanationBox.style.display = 'block';
            const expText = document.getElementById("explanationText");
            if (expText) {
                let rawExp = q.explanation || q.solution || ("Correct Option: " + String.fromCharCode(65 + correctIdx));
                expText.innerHTML = formatSolutionText(ensureMathDelimiter(rawExp));
            }
        } else {
            explanationBox.style.display = 'none';
        }
    }

    const reviewBtn = document.getElementById("reviewBtn");
    if (reviewBtn) {
        if (reviewStatus[idx]) {
            reviewBtn.innerHTML = `<i class="fa-solid fa-bookmark"></i> Unmark`;
            reviewBtn.className = "btn btn-warning active";
        } else {
            reviewBtn.innerHTML = `<i class="fa-regular fa-bookmark"></i> Review`;
            reviewBtn.className = "btn btn-outline";
        }
    }

    const nextBtn = document.getElementById("nextBtn");
    if (nextBtn) {
        const isOptionSelected = userAnswers[currentIndex] !== undefined;
        const isLastQuestion = currentIndex === questions.length - 1;

        if (isLastQuestion) {
            if (isOptionSelected) {
                nextBtn.innerHTML = `Submit Test <i class="fa-solid fa-paper-plane"></i>`;
                nextBtn.className = "btn btn-primary";
            } else {
                nextBtn.innerHTML = `Skip & Submit <i class="fa-solid fa-paper-plane"></i>`;
                nextBtn.className = "btn btn-outline";
            }
        } else if (isOptionSelected) {
            nextBtn.innerHTML = `Next <i class="fa-solid fa-chevron-right"></i>`;
            nextBtn.className = "btn btn-primary";
        } else {
            nextBtn.innerHTML = `Skip <i class="fa-solid fa-forward"></i>`;
            nextBtn.className = "btn btn-outline";
        }
    }

    renderPalette();

    const elementsToTypeset = [qTextElem, optionsBox, explanationBox].filter(Boolean);
    renderMathJax(elementsToTypeset);
}

function selectOption(oIdx) {
    delete skippedQuestions[currentIndex];
    if (currentMode === 'practice') {
        if (practiceRevealed[currentIndex]) return;
        selectedPracticeOptions[currentIndex] = oIdx;
        loadQuestion(currentIndex);
    } else {
        userAnswers[currentIndex] = oIdx;
        saveLocalDraft();
        loadQuestion(currentIndex);
    }
}

function revealPracticeAnswer() {
    if (selectedPracticeOptions[currentIndex] === undefined) return;
    
    delete skippedQuestions[currentIndex];
    userAnswers[currentIndex] = selectedPracticeOptions[currentIndex];
    practiceRevealed[currentIndex] = true;
    isTimerPaused = true;

    saveLocalDraft();
    loadQuestion(currentIndex);
}

function clearResponse() {
    delete userAnswers[currentIndex];
    delete reviewStatus[currentIndex];
    delete skippedQuestions[currentIndex];
    delete selectedPracticeOptions[currentIndex];
    delete practiceRevealed[currentIndex];
    saveLocalDraft();
    loadQuestion(currentIndex);
}

function markForReview() {
    if (reviewStatus[currentIndex]) {
        delete reviewStatus[currentIndex];
    } else {
        reviewStatus[currentIndex] = true;
    }
    saveLocalDraft();
    if (currentIndex < questions.length - 1) navigateQuestion(1);
    else loadQuestion(currentIndex);
}

function navigateQuestion(dir) {
    const nextIdx = currentIndex + dir;
    if (nextIdx >= 0 && nextIdx < questions.length) loadQuestion(nextIdx);
}

function handleNextOrSubmit() {
    const isLastQuestion = currentIndex === questions.length - 1;
    if (userAnswers[currentIndex] === undefined) {
        skippedQuestions[currentIndex] = true;
        saveLocalDraft();
    }

    if (isLastQuestion) {
        confirmSubmission();
    } else {
        navigateQuestion(1);
    }
}

function startTimer() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        if (isTimerPaused || isSubmitted) return;
        timeRemaining--;
        totalTimeSpentSec++;

        if (totalTimeSpentSec % 5 === 0) saveLocalDraft();

        let mins = Math.floor(timeRemaining / 60), secs = timeRemaining % 60;
        const tText = document.getElementById("timerText");
        if (tText) tText.innerText = `${mins < 10 ? "0" : ""}${mins}:${secs < 10 ? "0" : ""}${secs}`;
        
        if (timeRemaining <= 0) { 
            clearInterval(timerInterval); 
            timerInterval = null;
            submitTest(); 
        }
    }, 1000);
}

function confirmSubmission() {
    if (confirm(`Aapne ${Object.keys(userAnswers).length}/${questions.length} questions attempt kiye hain. Submit karna chahte hain?`)) {
        submitTest();
    }
}

function parseCorrectOption(q) {
    let val = q.correct !== undefined ? q.correct : (q.correct_option ?? q.ans ?? q.correctAnswer ?? 0);
    if (typeof val === 'number') return val;
    let str = val.toString().trim().toUpperCase();
    if (str === 'A' || str === '0') return 0;
    if (str === 'B' || str === '1') return 1;
    if (str === 'C' || str === '2') return 2;
    if (str === 'D' || str === '3') return 3;
    return parseInt(str, 10) || 0;
}

function openExitModal() { 
    const m = document.getElementById("exitModal");
    if (m) m.style.display = "flex"; 
}

function closeExitModal() { 
    const m = document.getElementById("exitModal");
    if (m) m.style.display = "none"; 
}

function exitExamConfirmed() { 
    saveLocalDraft(); 
    window.location.href = "tests.html"; 
}

async function submitTest() {
    isSubmitted = true;
    trackTestActivity();
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }

    await clearLocalDraft();

    let correctCount = 0, wrongCount = 0, skippedCount = 0, reviewCount = 0;

    questions.forEach((q, idx) => {
        let correctIdx = parseCorrectOption(q);
        if (reviewStatus[idx]) reviewCount++;
        if (userAnswers[idx] !== undefined) {
            if (userAnswers[idx] === correctIdx) correctCount++;
            else wrongCount++;
        } else {
            if (!reviewStatus[idx]) skippedCount++;
        }
    });

    let totalQ = questions.length;
    let posMarks = currentTest.marks_per_question !== undefined ? Number(currentTest.marks_per_question) : 1.0;
    let negMarks = currentTest.negative_marks !== undefined ? Number(currentTest.negative_marks) : (Number(currentTest.negative_marking) || 0.0);
    
    let scoreVal = (correctCount * posMarks) - (wrongCount * negMarks);

    let maxPossibleScore = totalQ * posMarks;
    let scorePct = maxPossibleScore > 0 ? Math.round((scoreVal / maxPossibleScore) * 100) : 0;
    let accuracyPct = (correctCount + wrongCount) > 0 ? Math.round((correctCount / (correctCount + wrongCount)) * 100) : 0;

    const tArea = document.getElementById("testArea");
    if (tArea) tArea.style.display = "none";

    const header = document.querySelector("header");
    if (header) header.style.display = "none";
    
    const rArea = document.getElementById("resultArea");
    if (rArea) {
        rArea.style.display = "block";
        window.scrollTo(0, 0);
    }

    const defaultAvatar = 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';
    const rName = document.getElementById("resUserName");
    if (rName) rName.innerText = currentUserProfile?.full_name || 'Student';
    
    const rPic = document.getElementById("resUserProfilePic");
    if (rPic) rPic.src = currentUserProfile?.avatar_url || defaultAvatar;

    const rScore = document.getElementById("resScoreVal");
    if (rScore) rScore.innerText = scoreVal.toFixed(2);
    
    const rTotal = document.getElementById("resScoreTotal");
    if (rTotal) rTotal.innerText = `Out of ${maxPossibleScore.toFixed(2)}`;
    
    const rTitle = document.getElementById("resTestTitle");
    if (rTitle) rTitle.innerText = currentTest.title || "Portal Test";
    
    let minsSpent = Math.floor(totalTimeSpentSec / 60);
    let secsSpent = totalTimeSpentSec % 60;
    const rTime = document.getElementById("resTimeTaken");
    if (rTime) rTime.innerText = `${minsSpent < 10 ? '0' : ''}${minsSpent} min, ${secsSpent < 10 ? '0' : ''}${secsSpent} sec`;

    if (document.getElementById("cntCorrectVal")) document.getElementById("cntCorrectVal").innerText = correctCount;
    if (document.getElementById("cntWrongVal")) document.getElementById("cntWrongVal").innerText = wrongCount;
    if (document.getElementById("cntSkippedVal")) document.getElementById("cntSkippedVal").innerText = skippedCount;

    if (document.getElementById("accuracyValText")) document.getElementById("accuracyValText").innerText = `${accuracyPct} %`;
    if (document.getElementById("scoreValText")) document.getElementById("scoreValText").innerText = `${scorePct < 0 ? 0 : scorePct} %`;

    if (document.getElementById("qaCorrect")) document.getElementById("qaCorrect").innerText = correctCount < 10 ? `0${correctCount}` : correctCount;
    if (document.getElementById("qaWrong")) document.getElementById("qaWrong").innerText = wrongCount < 10 ? `0${wrongCount}` : wrongCount;
    if (document.getElementById("qaSkipped")) document.getElementById("qaSkipped").innerText = skippedCount < 10 ? `0${skippedCount}` : skippedCount;

    try { renderQuestionAnalysisGrid(); } catch(e) { console.warn("Question Analysis grid render error:", e); }
    try { renderCharts(correctCount, wrongCount, skippedCount, accuracyPct, scorePct < 0 ? 0 : scorePct); } catch(e) { console.warn("Chart render error:", e); }

    await saveResultAndFetchRank(scoreVal, maxPossibleScore);
    renderMathJax();
}

function renderQuestionAnalysisGrid() {
    const grid = document.getElementById("analysisQGrid");
    const list = document.getElementById("analysisQList");
    if (!grid) return;
    grid.innerHTML = "";
    if (list) list.innerHTML = "";

    questions.forEach((q, idx) => {
        let correctIdx = parseCorrectOption(q);
        let userAns = userAnswers[idx];
        let btn = document.createElement("button");
        btn.className = "q-status-btn";
        btn.innerText = idx + 1;

        let statusClass = "";
        let statusBadgeText = "";

        if (userAns !== undefined) {
            if (userAns === correctIdx) {
                btn.classList.add("correct");
                statusClass = "res-correct";
                statusBadgeText = "✔ Correct";
            } else {
                btn.classList.add("wrong");
                statusClass = "res-wrong";
                statusBadgeText = "✖ Wrong";
            }
        } else if (reviewStatus[idx]) {
            btn.classList.add("review");
            statusClass = "res-review";
            statusBadgeText = "📌 Review";
        } else {
            btn.classList.add("skipped");
            statusClass = "res-skipped";
            statusBadgeText = "⚠ Skipped";
        }

        btn.onclick = () => openQuestionDetailModal(idx);
        grid.appendChild(btn);

        if (list) {
            const listCard = document.createElement("div");
            listCard.className = `res-list-card ${statusClass}`;
            listCard.innerHTML = `
                <div class="res-list-head">
                    <span class="res-list-num">Q${idx + 1}.</span>
                    <span style="font-size: 11px; font-weight: bold;">${statusBadgeText}</span>
                </div>
                <div class="res-list-text">${ensureMathDelimiter(q.question_text || q.question)}</div>
            `;
            listCard.onclick = () => openQuestionDetailModal(idx);
            list.appendChild(listCard);
        }
    });

    switchResultPaletteView(currentResultPaletteView);
    renderMathJax();
}

function openQuestionDetailModal(idx) {
    const q = questions[idx];
    const userAnsIdx = userAnswers[idx];
    const correctIdx = parseCorrectOption(q);
    const options = q.options || [q.option1, q.option2, q.option3, q.option4];

    let userAnsText = userAnsIdx !== undefined ? ensureMathDelimiter(options[userAnsIdx]) : "Not Answered";
    let correctAnsText = ensureMathDelimiter(options[correctIdx]);
    let isCorrect = userAnsIdx === correctIdx;

    let statusText = isCorrect ? "✔ Correct" : (userAnsIdx !== undefined ? "✖ Wrong" : "⚠ Skipped / Not Answered");
    let diagramHtml = getDiagramHtml(q);

    let detailHtml = `
        <div id="qDetailModal" style="position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.75); display:flex; justify-content:center; align-items:center; z-index:9999; padding:12px; box-sizing:border-box;">
            <div style="background:var(--surface, #1e293b); color:var(--text-main, #fff); border-radius:12px; padding:16px; width:100%; max-width:450px; max-height:85vh; overflow-y:auto; overflow-x:hidden; box-shadow:0 8px 32px rgba(0,0,0,0.5); box-sizing:border-box;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <h3 style="font-size:16px; margin:0;">Question ${idx + 1} Analysis</h3>
                    <button onclick="document.getElementById('qDetailModal').remove()" style="background:none; border:none; color:var(--text-main, #fff); font-size:18px; cursor:pointer; padding:4px;">✖</button>
                </div>
                <div style="font-size:13px; font-weight:700; margin-bottom:10px; color:${isCorrect ? '#10b981' : (userAnsIdx !== undefined ? '#f43f5e' : '#f59e0b')};">${statusText}</div>
                
                <div style="font-size:14px; margin-bottom:12px; font-weight:600; line-height:1.4; max-width:100%; overflow-x:auto;">
                    ${ensureMathDelimiter(q.question_text || q.question)}
                    ${diagramHtml}
                </div>
                
                <div style="font-size:13px; margin-bottom:8px; padding:8px; background:rgba(255,255,255,0.05); border-radius:6px; max-width:100%; overflow-x:auto;">
                    <b>Your Choice:</b> <span style="color:${isCorrect ? '#10b981' : '#f43f5e'};">${userAnsText}</span>
                </div>
                
                <div style="font-size:13px; margin-bottom:12px; padding:8px; background:rgba(16,185,129,0.1); border-radius:6px; color:#10b981; max-width:100%; overflow-x:auto;">
                    <b>Correct Answer:</b> ${correctAnsText}
                </div>
                
                ${(q.explanation || q.solution) ? `
                    <div style="font-size:12.5px; color:#cbd5e1; border-top:1px solid #334155; padding-top:10px; margin-top:8px; max-width:100%; overflow-x:auto; -webkit-overflow-scrolling:touch;">
                        <b style="color:#94a3b8; display:block; margin-bottom:4px;">Explanation:</b> 
                        <div style="max-width:100%; overflow-x:auto; line-height: 1.6;">
                            ${formatSolutionText(ensureMathDelimiter(q.explanation || q.solution))}
                        </div>
                    </div>` : ''}
                
                <button onclick="document.getElementById('qDetailModal').remove()" style="margin-top:16px; width:100%; padding:10px; background:#007bff; color:#fff; border:none; border-radius:6px; font-weight:700; cursor:pointer;">Close</button>
            </div>
        </div>
    `;

    const existingModal = document.getElementById("qDetailModal");
    if (existingModal) existingModal.remove();
    document.body.insertAdjacentHTML('beforeend', detailHtml);
    renderMathJax([document.getElementById("qDetailModal")]);
}

async function saveResultAndFetchRank(scoreVal, totalMarks) {
    const rankValElem = document.getElementById("resRankVal");
    const rankTotalElem = document.getElementById("resRankTotal");

    if (!window.supabaseClient || !currentTest || currentTest.id === 'demo_test') {
        if (rankValElem) rankValElem.innerText = "#1";
        if (rankTotalElem) rankTotalElem.innerText = "Out of 1 (Demo)";
        return;
    }

    try {
        const { data: { user } } = await window.supabaseClient.auth.getUser();
        if (!user) {
            if (rankValElem) rankValElem.innerText = "#1";
            if (rankTotalElem) rankTotalElem.innerText = "Out of 1 (Guest)";
            return;
        }

        let correctCount = 0, wrongCount = 0, skippedCount = 0;
        questions.forEach((q, idx) => {
            let correctIdx = parseCorrectOption(q);
            if (userAnswers[idx] !== undefined) {
                if (userAnswers[idx] === correctIdx) correctCount++;
                else wrongCount++;
            } else {
                skippedCount++;
            }
        });

        const attempted = correctCount + wrongCount;
        const accuracyPct = attempted > 0 ? Math.round((correctCount / attempted) * 100) : 0;

        const formattedUserAnswers = questions.map((q, idx) => {
            let correctIdx = parseCorrectOption(q);
            let userAnsIdx = userAnswers[idx];
            let options = q.options || [q.option1, q.option2, q.option3, q.option4];

            let svgContent = q.diagram_svg || q.svg || q.svg_code || null;
            if (typeof svgContent === 'string') {
                svgContent = svgContent.trim() !== '' ? svgContent.trim() : null;
            } else {
                svgContent = null;
            }

            let rawImg = q.image_url || q.image || q.q_image || q.questionImg || q.imgUrl || q.imageUrl || (q.question_data && q.question_data.image_url) || null;
            let imgUrl = null;
            if (rawImg && typeof rawImg === 'string' && rawImg !== 'null' && rawImg !== 'undefined' && rawImg.trim() !== '') {
                imgUrl = rawImg.trim();
            }

            return {
                qIndex: idx,
                questionText: q.question_text || q.question || q.title || `Question ${idx + 1}`,
                userAnsIndex: userAnsIdx !== undefined ? userAnsIdx : null,
                userAnsText: userAnsIdx !== undefined ? (options[userAnsIdx] || "N/A") : "Not Answered",
                correctAnsIndex: correctIdx,
                correctAnsText: options[correctIdx] || "N/A",
                isCorrect: userAnsIdx === correctIdx,
                isSkipped: userAnsIdx === undefined || userAnsIdx === null,
                explanation: q.explanation || q.solution || q.exp || "",
                diagram_svg: svgContent,
                image_url: imgUrl,
                options: options
            };
        });

        const { error: insertErr } = await window.supabaseClient
            .from('test_results')
            .upsert([{
                user_id: user.id,
                test_id: currentTest.id,
                test_title: currentTest.title || 'Portal Test',
                subject: currentTest.subject || currentTest.subject_name || 'General',
                score: scoreVal.toString(),
                total_marks: totalMarks.toString(),
                accuracy: accuracyPct,
                correct_answers: correctCount,
                wrong_answers: wrongCount,
                skipped_answers: skippedCount,
                time_taken_sec: totalTimeSpentSec,
                user_answers: formattedUserAnswers,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            }], { onConflict: 'user_id,test_id' });

        if (insertErr) {
            console.error("Supabase Save Result Error:", insertErr.message || JSON.stringify(insertErr));
        }

        const { data: results, error } = await window.supabaseClient
            .from('test_results')
            .select('user_id, score, time_taken_sec')
            .eq('test_id', currentTest.id);

        if (error || !results || results.length === 0) {
            if (rankValElem) rankValElem.innerText = "#1";
            if (rankTotalElem) rankTotalElem.innerText = "Out of 1";
            return;
        }

        let userBestMap = {};
        results.forEach(r => {
            const numScore = parseFloat(r.score) || 0;
            if (!userBestMap[r.user_id] || numScore > userBestMap[r.user_id].score) {
                userBestMap[r.user_id] = { ...r, score: numScore };
            }
        });

        let sortedList = Object.values(userBestMap).sort((a, b) => {
            if (b.score !== a.score) return b.score - a.score;
            return (a.time_taken_sec || 0) - (b.time_taken_sec || 0);
        });

        let myRank = sortedList.findIndex(r => r.user_id === user.id) + 1;
        let totalParticipants = sortedList.length;

        if (rankValElem) rankValElem.innerText = myRank > 0 ? `#${myRank}` : '#1';
        if (rankTotalElem) rankTotalElem.innerText = `Out of ${totalParticipants || 1}`;

    } catch (err) {
        console.warn("Ranking/Cloud Save Exception:", err);
        if (rankValElem) rankValElem.innerText = "#1";
        if (rankTotalElem) rankTotalElem.innerText = "Out of 1";
    }
}

function renderCharts(correct, wrong, skipped, accuracy, score) {
    if (chartBrief) chartBrief.destroy();
    if (chartAccuracy) chartAccuracy.destroy();
    if (chartScore) chartScore.destroy();

    const ctxBrief = document.getElementById('briefAnalysisChart')?.getContext('2d');
    if (ctxBrief) {
        chartBrief = new Chart(ctxBrief, {
            type: 'doughnut',
            data: {
                labels: ['Correct', 'Wrong', 'Skipped'],
                datasets: [{
                    data: [correct, wrong, skipped],
                    backgroundColor: ['#10b981', '#f43f5e', '#ea580c'],
                    borderWidth: 0
                }]
            },
            options: { cutout: '70%', plugins: { legend: { display: false } } }
        });
    }

    const ctxAcc = document.getElementById('accuracyChart')?.getContext('2d');
    if (ctxAcc) {
        chartAccuracy = new Chart(ctxAcc, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [accuracy, 100 - accuracy],
                    backgroundColor: ['#10b981', '#f43f5e'],
                    borderWidth: 0
                }]
            },
            options: { cutout: '80%', plugins: { legend: { display: false } } }
        });
    }

    const ctxScore = document.getElementById('scoreChart')?.getContext('2d');
    if (ctxScore) {
        chartScore = new Chart(ctxScore, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [score, 100 - score],
                    backgroundColor: ['#10b981', '#f43f5e'],
                    borderWidth: 0
                }]
            },
            options: { cutout: '80%', plugins: { legend: { display: false } } }
        });
    }
}

function reattemptTest() {
    window.location.href = `take-test.html?id=${currentTest?.id || 'demo_test'}&mode=${currentMode}&reattempt=true`;
}

function viewPerformance() {
    const testId = currentTest?.id || 'demo_test';
    window.location.href = `performance.html?test_id=${testId}`;
}

function viewLeaderboard() {
    const testId = currentTest?.id || 'demo_test';
    window.location.href = `tests.html?tab=leaderboard&test_id=${testId}`;
}

async function shareOnWhatsApp() {
    const resultElement = document.getElementById("resultArea");
    if (!resultElement) return;

    try {
        if (typeof html2canvas === 'undefined') {
            alert("html2canvas library missing hai!");
            return;
        }

        const userName = document.querySelector("#resUserName")?.innerText || "Student";
        const testTitle = typeof currentTest !== 'undefined' && currentTest?.title ? currentTest.title : "Test Result";
        const score = document.getElementById("resScoreVal")?.innerText || "0";
        const rank = document.getElementById("resRankVal")?.innerText || "#1";
        const testId = typeof currentTest !== 'undefined' && currentTest?.id ? currentTest.id : "";

        const shareUrl = `${window.location.host}/take-test.html${testId ? `?id=${testId}` : ''}`;

        const userImgEl = document.querySelector("#resUserProfilePic");
        let avatarSrc = null;

        if (userImgEl && userImgEl.src) {
            try {
                const c = document.createElement("canvas");
                c.width = userImgEl.naturalWidth || userImgEl.width || 100;
                c.height = userImgEl.naturalHeight || userImgEl.height || 100;
                const ctx = c.getContext("2d");
                ctx.drawImage(userImgEl, 0, 0);
                avatarSrc = c.toDataURL("image/png");
            } catch (e) {
                avatarSrc = userImgEl.src;
            }
        }

        const shareCard = document.createElement("div");
        shareCard.style.position = "fixed";
        shareCard.style.left = "-9999px";
        shareCard.style.top = "-9999px";
        shareCard.style.width = "380px";
        shareCard.style.padding = "24px";
        shareCard.style.borderRadius = "20px";
        shareCard.style.background = "linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)";
        shareCard.style.color = "#ffffff";
        shareCard.style.fontFamily = "sans-serif";

        const avatarHtml = avatarSrc 
            ? `<img src="${avatarSrc}" style="width: 75px; height: 75px; border-radius: 50%; object-fit: cover; margin: 0 auto 10px; display: block; border: 3px solid #a855f7;" />`
            : `<div style="width: 75px; height: 75px; border-radius: 50%; background: linear-gradient(135deg, #a855f7, #ec4899); margin: 0 auto 10px; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: bold; color: white;">${userName.charAt(0).toUpperCase()}</div>`;

        shareCard.innerHTML = `
            <div style="text-align: center; margin-bottom: 18px;">
                ${avatarHtml}
                <h3 style="margin: 0; font-size: 20px; color: #f8fafc; font-weight: 700;">${userName}</h3>
                <p style="margin: 4px 0 0; font-size: 13px; color: #c084fc;">${testTitle}</p>
            </div>
            
            <div style="display: flex; gap: 10px; margin-bottom: 18px;">
                <div style="flex: 1; background: rgba(30, 41, 59, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); padding: 12px; border-radius: 12px; text-align: center;">
                    <span style="font-size: 11px; color: #94a3b8; display: block; margin-bottom: 4px;">SCORE</span>
                    <strong style="font-size: 22px; color: #4ade80;">${score}</strong>
                </div>
                <div style="flex: 1; background: rgba(30, 41, 59, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); padding: 12px; border-radius: 12px; text-align: center;">
                    <span style="font-size: 11px; color: #94a3b8; display: block; margin-bottom: 4px;">RANK</span>
                    <strong style="font-size: 22px; color: #60a5fa;">${rank}</strong>
                </div>
            </div>

            <div style="text-align: center; border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: 12px;">
                <span style="font-size: 10px; color: #94a3b8; display: block; margin-bottom: 2px;">Take this test at:</span>
                <strong style="font-size: 12px; color: #a7f3d0; word-break: break-all;">${shareUrl}</strong>
            </div>
        `;

        document.body.appendChild(shareCard);

        const canvas = await html2canvas(shareCard, {
            scale: 2,
            useCORS: true,
            allowTaint: true,
            backgroundColor: null
        });

        document.body.removeChild(shareCard);

        canvas.toBlob(async (blob) => {
            if (!blob) return;
            const file = new File([blob], `Test_Result.png`, { type: 'image/png' });

            if (navigator.canShare && navigator.canShare({ files: [file] })) {
                try {
                    await navigator.share({ files: [file] });
                } catch (e) {
                    console.log("Cancelled", e);
                }
            } else {
                const link = document.createElement('a');
                link.download = `Test_Result.png`;
                link.href = canvas.toDataURL('image/png');
                link.click();
            }
        }, 'image/png');

    } catch (err) {
        console.error("Error:", err);
    }
}

function shareNative() {
    shareOnWhatsApp();
}

function toggleSolutions() {
    const solContainer = document.getElementById("solutionsContainer");
    if (!solContainer) return;
    if (solContainer.style.display === "none" || solContainer.style.display === "") {
        renderSolutions();
        solContainer.style.display = "block";
        solContainer.scrollIntoView({ behavior: 'smooth' });
    } else {
        solContainer.style.display = "none";
    }
}

function filterSolutions(type, el) {
    currentAnalysisFilter = type;
    if (el) {
        document.querySelectorAll('.analysis-chip').forEach(c => c.classList.remove('active-all', 'active'));
        el.classList.add('active');
    }
    renderSolutions();
}

function renderSolutions() {
    let html = "";
    let cntAll = questions.length;
    let cntCorrect = 0, cntIncorrect = 0, cntSkipped = 0, cntReview = 0;

    questions.forEach((q, idx) => {
        let correctIdx = parseCorrectOption(q);
        let userAnsIdx = userAnswers[idx];
        let isCorrect = userAnsIdx === correctIdx;
        let isUnanswered = userAnsIdx === undefined;
        let isReview = !!reviewStatus[idx];

        if (isCorrect) cntCorrect++;
        else if (!isUnanswered) cntIncorrect++;

        if (isReview) cntReview++;
        else if (isUnanswered) cntSkipped++;

        if (currentAnalysisFilter === 'correct' && !isCorrect) return;
        if (currentAnalysisFilter === 'incorrect' && (isCorrect || isUnanswered)) return;
        if (currentAnalysisFilter === 'skipped' && (!isUnanswered || isReview)) return;
        if (currentAnalysisFilter === 'review' && !isReview) return;

        let options = q.options || [q.option1, q.option2, q.option3, q.option4];
        
        let badgeClass = '';
        let badgeText = '';

        if (isCorrect) {
            badgeClass = 'badge-success';
            badgeText = '✔ Correct';
        } else if (isReview) {
            badgeClass = 'badge-warning';
            badgeText = '📌 Review';
        } else if (isUnanswered) {
            badgeClass = 'badge-warning';
            badgeText = '⚠ Skipped';
        } else {
            badgeClass = 'badge-danger';
            badgeText = '✖ Wrong';
        }

        let exp = q.explanation || q.solution;
        let diagramHtml = getDiagramHtml(q);

        html += `
            <div class="sol-card" style="position: relative; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); padding:12px; border-radius:8px; margin-bottom:12px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                    <span class="badge ${badgeClass}" style="font-size:12px; font-weight:bold;">${badgeText}</span>
                    <button onclick="reportBug(${idx})" style="background: rgba(244, 63, 94, 0.1); color: #f43f5e; border: 1px solid rgba(244, 63, 94, 0.3); border-radius: 6px; padding: 2px 8px; font-size: 11px; font-weight: 700; cursor: pointer;">
                        <i class="fa-solid fa-bug"></i> Report Bug
                    </button>
                </div>
                <h4 style="margin-bottom: 6px; font-size:13.5px;">Q${idx + 1}. ${ensureMathDelimiter(q.question_text || q.question || '')}</h4>
                ${diagramHtml}
                <p style="font-size: 12.5px; margin-bottom: 4px;">
                    <b>Your Choice:</b> ${userAnsIdx !== undefined ? `<span style="color:${isCorrect ? '#10b981' : '#f43f5e'}">${ensureMathDelimiter(options[userAnsIdx])}</span>` : '<i>Not Answered</i>'}
                </p>
                <p style="font-size: 12.5px; color: #10b981;">
                    <b>Correct Answer:</b> ${ensureMathDelimiter(options[correctIdx])}
                </p>
                ${exp ? `<p style="font-size: 12px; color: #94a3b8; margin-top: 6px; border-top: 1px dashed #334155; padding-top: 6px; line-height: 1.6;"><b>Explanation:</b><br>${formatSolutionText(ensureMathDelimiter(exp))}</p>` : ''}
            </div>
        `;
    });

    const cAll = document.getElementById('cntAll'); if (cAll) cAll.innerText = cntAll;
    const cCor = document.getElementById('cntCorrect'); if (cCor) cCor.innerText = cntCorrect;
    const cInc = document.getElementById('cntIncorrect'); if (cInc) cInc.innerText = cntIncorrect;
    const cSkp = document.getElementById('cntSkipped'); if (cSkp) cSkp.innerText = cntSkipped;
    const cRev = document.getElementById('cntReview'); if (cRev) cRev.innerText = cntReview;

    const solList = document.getElementById("solutionsList");
    if (solList) {
        solList.innerHTML = html || `<div style="padding: 10px; text-align: center; color: #94a3b8; font-size: 12px;">Is category me koi question nahi hai.</div>`;
    }
    renderMathJax();
}

function switchInstTab(tabName) {
    document.querySelectorAll('.inst-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.inst-tab-content').forEach(content => content.classList.remove('active'));

    if (tabName === 'test') {
        document.getElementById('btnTabTest')?.classList.add('active');
        document.getElementById('tabContentTest')?.classList.add('active');
    } else {
        document.getElementById('btnTabGeneral')?.classList.add('active');
        document.getElementById('tabContentGeneral')?.classList.add('active');
    }
}
function trackTestActivity() {
    if (!currentTest) return;
    try {
        let recent = JSON.parse(localStorage.getItem("recentFiles") || "[]");
        let cleanUrl = `take-test.html?id=${currentTest.id}`;
        let existingIndex = recent.findIndex(f => f.url && f.url.includes(currentTest.id));
        if (existingIndex !== -1) {
            recent.splice(existingIndex, 1);
        }
        recent.unshift({
            title: currentTest.title || "Portal Test",
            url: cleanUrl,
            meta: currentTest.class_level || currentTest.subject || "Mock Test",
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isTest: true,
            downloaded: false
        });
        recent = recent.slice(0, 20);
        localStorage.setItem("recentFiles", JSON.stringify(recent));
    } catch(e) {
        console.warn("Activity track error:", e);
    }
}


async function reportBug(questionIdx) {
    const q = questions[questionIdx];
    const userReason = prompt(`Question ${questionIdx + 1} me kya galti hai? Brief me likhein:`);
    if (userReason) {
        if (window.supabaseClient) {
            try {
                const { data: { user } } = await window.supabaseClient.auth.getUser();
                const testTitle = currentTest ? currentTest.title : 'Demo Test';
                const classStream = currentTest ? (currentTest.class_level || currentTest.stream || 'General') : 'General';

                await window.supabaseClient.from('bug_reports').insert([{
                    user_id: user?.id || null,
                    test_id: currentTest ? currentTest.id : 'demo',
                    test_title: testTitle,
                    class_stream: classStream,
                    question_index: questionIdx,
                    question_text: q.question_text || q.question,
                    issue_description: userReason
                }]);
                alert("Aapki bug report submit ho gayi hai! Admin jald ise check karega.");
            } catch (err) {
                console.error("Bug report error:", err);
                alert("Bug report save karne me dikkat hui.");
            }
        } else {
            alert("Bug reported locally!");
        }
    }
}
