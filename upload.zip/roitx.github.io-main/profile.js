let currentUser = null;
let currentAvatarUrl = null;
let cropper = null;
let dangerHideTimer = null;
let PRESET_AVATARS = [];

// JSON File load karne ka function
async function loadAvatarsFromJSON() {
  try {
    const response = await fetch('assets/3d/avatars.json');
    if (!response.ok) throw new Error("Avatars JSON load failed");
    PRESET_AVATARS = await response.json();
    renderAvatarGrid();
  } catch (error) {
    console.error("Avatar load error:", error);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadUserProfile();
  loadAvatarsFromJSON(); // Static array call ki jagah JSON fetch karo
});

function renderAvatarGrid() {
  const grid = document.getElementById("avatarGrid");
  if (!grid) return;
  
  grid.innerHTML = PRESET_AVATARS.map((item, index) => {
    return `
      <div class="avatar-card-item" onclick="selectPresetAvatar(${index})">
        <div class="avatar-option-item">
          <img src="${item.src}" alt="${item.title}">
        </div>
        <span class="avatar-label">${item.title}</span>
      </div>
    `;
  }).join('');
}

async function selectPresetAvatar(index) {
  const selected = PRESET_AVATARS[index];
  if (!selected) return;

  closeAvatarSelector();
  
  currentAvatarUrl = selected.src;
  localStorage.setItem("userPhoto", currentAvatarUrl);
  renderAvatarImage(currentAvatarUrl);

  if (currentUser) {
    try {
      await window.supabaseClient
        .from('profiles')
        .upsert({ 
          id: currentUser.id, 
          email: currentUser.email,
          avatar_url: currentAvatarUrl, 
          updated_at: new Date().toISOString()
        });
    } catch (err) {
      console.warn("Avatar DB update error:", err);
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadUserProfile();
  renderAvatarGrid();
});

// Danger Zone: 5 Seconds Reveal Handler
function toggleDangerDeleteBtn() {
  const wrapper = document.getElementById("dangerDeleteWrapper");
  const notice = document.getElementById("dangerZoneTimerNotice");
  if (!wrapper) return;

  if (dangerHideTimer) clearTimeout(dangerHideTimer);

  wrapper.style.display = "block";
  if (notice) notice.innerText = "(Visible for 5s)";

  let secondsLeft = 5;
  const interval = setInterval(() => {
    secondsLeft--;
    if (secondsLeft > 0) {
      if (notice) notice.innerText = `(Hiding in ${secondsLeft}s)`;
    } else {
      clearInterval(interval);
    }
  }, 1000);

  dangerHideTimer = setTimeout(() => {
    wrapper.style.display = "none";
    if (notice) notice.innerText = "(Tap to unlock)";
  }, 5000);
}

// Calculate Profile Completion %
function getCompletionPercentage() {
  const fields = [
    document.getElementById("fullNameInput")?.value.trim(),
    document.getElementById("phoneInput")?.value.trim(),
    document.getElementById("classSelect")?.value.trim(),
    document.getElementById("streamSelect")?.value.trim(),
    document.getElementById("institutionInput")?.value.trim(),
    document.getElementById("cityInput")?.value.trim(),
    document.getElementById("stateInput")?.value.trim(),
    document.getElementById("pincodeInput")?.value.trim(),
    currentAvatarUrl
  ];

  let filledCount = 0;
  fields.forEach(val => {
    if (val) filledCount++;
  });

  return Math.round((filledCount / fields.length) * 100);
}

// Update Badge UI
function updateProfileProgress() {
  const percentage = getCompletionPercentage();
  const badge = document.getElementById("profileProgressBadge");

  if (badge) {
    if (percentage >= 100) {
      badge.innerHTML = '<i class="fa-solid fa-star"></i>';
      badge.classList.add("completed");
    } else {
      badge.innerText = `${percentage}%`;
      badge.classList.remove("completed");
    }
  }
}

function triggerCongratulationsAnimation() {
  if (typeof confetti === "function") {
    confetti({
      particleCount: 130,
      spread: 80,
      origin: { y: 0.6 }
    });
  }
}

// Bottom Sheet Option Handlers
function openPhotoOptions() {
  const removeBtn = document.getElementById("sheetRemoveBtn");
  if (currentAvatarUrl) {
    removeBtn.style.display = "flex";
  } else {
    removeBtn.style.display = "none";
  }
  document.getElementById("photoOptionsSheet").classList.add("active");
}

function closePhotoOptions(e) {
  if (e) e.stopPropagation();
  document.getElementById("photoOptionsSheet").classList.remove("active");
}

function triggerCamera() {
  closePhotoOptions();
  document.getElementById("avatarFileInputCamera").click();
}

function triggerGallery() {
  closePhotoOptions();
  document.getElementById("avatarFileInputGallery").click();
}

function openAvatarSelector() {
  closePhotoOptions();
  document.getElementById("avatarPickerSheet").classList.add("active");
}

function closeAvatarSelector(e) {
  if (e) e.stopPropagation();
  document.getElementById("avatarPickerSheet").classList.remove("active");
}

// Account Delete Confirmation Modal Handlers
function openDeleteConfirmModal() {
  if (!currentUser || !currentUser.email) return;

  const emailLabel = document.getElementById("confirmEmailLabel");
  const emailInput = document.getElementById("deleteConfirmEmailInput");
  const deleteBtn = document.getElementById("confirmDeleteActionBtn");

  if (emailLabel) emailLabel.innerText = `Type "${currentUser.email}" to confirm:`;
  if (emailInput) emailInput.value = "";
  
  if (deleteBtn) {
    deleteBtn.disabled = true;
    deleteBtn.style.opacity = "0.5";
    deleteBtn.style.cursor = "not-allowed";
  }

  document.getElementById("deleteConfirmModal").style.display = "flex";
}

function closeDeleteConfirmModal() {
  document.getElementById("deleteConfirmModal").style.display = "none";
}

function validateDeleteEmailInput() {
  const emailInput = document.getElementById("deleteConfirmEmailInput").value.trim();
  const deleteBtn = document.getElementById("confirmDeleteActionBtn");

  if (currentUser && emailInput.toLowerCase() === currentUser.email.toLowerCase()) {
    deleteBtn.disabled = false;
    deleteBtn.style.opacity = "1";
    deleteBtn.style.cursor = "pointer";
  } else {
    deleteBtn.disabled = true;
    deleteBtn.style.opacity = "0.5";
    deleteBtn.style.cursor = "not-allowed";
  }
}

// Dynamic Action Buttons Visibility Toggler
function applyRoleBasedUI(role, permissions = {}) {
  const normalizedRole = (role || "student").toLowerCase();
  const userRoleBadge = document.getElementById("userRoleBadge");
  const adminToolsSection = document.getElementById("adminToolsSection");

  // DOM Elements
  const adminBtn = document.getElementById("adminBtn");
  const manageTeamBtn = document.getElementById("manageTeamBtn");
  const sendNotifBtn = document.getElementById("sendNotifBtn");
  const uploadTestBtn = document.getElementById("uploadTestBtn");
  const aiTestBtn = document.getElementById("aiTestBtn");
  const uploadPyqBtn = document.getElementById("uploadPyqBtn");
  const managePyqBtn = document.getElementById("managePyqBtn");
  const uploadFlashcardBtn = document.getElementById("uploadFlashcardBtn");
  const manageFlashcardBtn = document.getElementById("manageFlashcardBtn");

  // Reset Display
  if (adminToolsSection) adminToolsSection.style.display = "none";
  if (adminBtn) adminBtn.style.display = "none";
  if (manageTeamBtn) manageTeamBtn.style.display = "none";
  if (sendNotifBtn) sendNotifBtn.style.display = "none";
  if (uploadTestBtn) uploadTestBtn.style.display = "none";
  if (aiTestBtn) aiTestBtn.style.display = "none";
  if (uploadPyqBtn) uploadPyqBtn.style.display = "none";
  if (managePyqBtn) managePyqBtn.style.display = "none";
  if (uploadFlashcardBtn) uploadFlashcardBtn.style.display = "none";
  if (manageFlashcardBtn) manageFlashcardBtn.style.display = "none";

  const isSuperAdmin = (currentUser && currentUser.email && currentUser.email.toLowerCase() === "rohitrajgoh91@gmail.com") || normalizedRole === "superadmin";

  let hasAnyAdminPrivilege = false;

  if (isSuperAdmin) {
    if (userRoleBadge) userRoleBadge.innerHTML = '<i class="fa-solid fa-crown"></i> Platform Super Admin';
    hasAnyAdminPrivilege = true;
    
    if (adminBtn) adminBtn.style.display = "flex";
    if (manageTeamBtn) manageTeamBtn.style.display = "flex";
    if (permissions.send_notif !== false && sendNotifBtn) sendNotifBtn.style.display = "flex";
    if (permissions.manage_test !== false && uploadTestBtn) uploadTestBtn.style.display = "flex";
    if (permissions.ai_test !== false && aiTestBtn) aiTestBtn.style.display = "flex";
    if (permissions.upload_pyq !== false && uploadPyqBtn) uploadPyqBtn.style.display = "flex";
    if (permissions.manage_pyq !== false && managePyqBtn) managePyqBtn.style.display = "flex";
    if (uploadFlashcardBtn) uploadFlashcardBtn.style.display = "flex";
    if (manageFlashcardBtn) manageFlashcardBtn.style.display = "flex";

  } else if (normalizedRole === "admin") {
    if (userRoleBadge) userRoleBadge.innerHTML = '<i class="fa-solid fa-user-gear"></i> Admin';
    hasAnyAdminPrivilege = true;
    
    if (adminBtn) adminBtn.style.display = "flex";
    if (manageTeamBtn) manageTeamBtn.style.display = "flex";
    if (sendNotifBtn) sendNotifBtn.style.display = "flex";
    if (uploadTestBtn) uploadTestBtn.style.display = "flex";
    if (aiTestBtn) aiTestBtn.style.display = "flex";
    if (uploadPyqBtn) uploadPyqBtn.style.display = "flex";
    if (managePyqBtn) managePyqBtn.style.display = "flex";
    if (uploadFlashcardBtn) uploadFlashcardBtn.style.display = "flex";
    if (manageFlashcardBtn) manageFlashcardBtn.style.display = "flex";

  } else if (normalizedRole === "teammate" || normalizedRole === "moderator") {
    if (userRoleBadge) userRoleBadge.innerHTML = '<i class="fa-solid fa-user-shield"></i> Official Teammate';

    if (permissions.admin_panel || permissions.send_notif || permissions.manage_test || permissions.ai_test || permissions.upload_pyq || permissions.manage_pyq) {
      hasAnyAdminPrivilege = true;
    }

    if (permissions.admin_panel && adminBtn) adminBtn.style.display = "flex";
    if (permissions.send_notif && sendNotifBtn) sendNotifBtn.style.display = "flex";
    if (permissions.manage_test && uploadTestBtn) uploadTestBtn.style.display = "flex";
    if (permissions.ai_test && aiTestBtn) aiTestBtn.style.display = "flex";
    if (permissions.upload_pyq && uploadPyqBtn) uploadPyqBtn.style.display = "flex";
    if (permissions.manage_pyq && managePyqBtn) managePyqBtn.style.display = "flex";
    if (uploadFlashcardBtn) uploadFlashcardBtn.style.display = "flex";
    if (manageFlashcardBtn) manageFlashcardBtn.style.display = "flex";

  } else {
    if (userRoleBadge) userRoleBadge.innerHTML = '<i class="fa-solid fa-graduation-cap"></i> Active Student';
  }

  // Agar user admin/teammate hai tabhi toggle bar dikhega warna hide rahega
  if (hasAnyAdminPrivilege && adminToolsSection) {
    adminToolsSection.style.display = "block";
  }
}

// Toggle Handler Function for Admin Menu
function toggleAdminToolsMenu() {
  const container = document.getElementById("adminToolsContainer");
  const icon = document.getElementById("adminToolsToggleIcon");
  if (!container) return;

  if (container.style.display === "none" || container.style.display === "") {
    container.style.display = "block";
    if (icon) icon.style.transform = "rotate(180deg)";
  } else {
    container.style.display = "none";
    if (icon) icon.style.transform = "rotate(0deg)";
  }
}
// Load User Profile Data with Role Support
async function loadUserProfile() {
  if (!window.supabaseClient) return;

  const user = await window.getCurrentUser();
  if (!user) {
    window.location.href = window.getPageUrl ? window.getPageUrl("login.html") : "login.html";
    return;
  }

  currentUser = user;
  document.getElementById("emailInput").value = user.email || "";

  // Extract Fallback Google Data directly from auth meta
  const googleName = user.user_metadata?.full_name || user.user_metadata?.name || "";
  const googleAvatar = user.user_metadata?.avatar_url || user.user_metadata?.picture || null;

  try {
    const { data, error } = await window.supabaseClient
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    if (error) console.error("Profile Fetch Error:", error);

    const userRole = data?.role || "student";
    const permissions = data?.permissions || {};
    
    applyRoleBasedUI(userRole, permissions);

    const displayName = data?.full_name || googleName || user.email.split('@')[0];
    const finalAvatar = data?.avatar_url || googleAvatar;

    document.getElementById("fullNameInput").value = data?.full_name || googleName || "";
    document.getElementById("countryCodeSelect").value = data?.country_code || "+91";
    document.getElementById("phoneInput").value = data?.phone || "";
    document.getElementById("classSelect").value = data?.target_class || "";
    document.getElementById("streamSelect").value = data?.stream || "";
    document.getElementById("institutionInput").value = data?.institution || "";
    document.getElementById("cityInput").value = data?.city || "";
    document.getElementById("stateInput").value = data?.state || "";
    if (document.getElementById("pincodeInput")) {
      document.getElementById("pincodeInput").value = data?.pincode || "";
    }

    document.getElementById("userDisplayName").innerText = displayName;

    if (finalAvatar) {
      currentAvatarUrl = finalAvatar;
      renderAvatarImage(finalAvatar);
    } else {
      renderInitialAvatar();
    }

  } catch (err) {
    console.warn("Could not fetch profile details:", err);
    document.getElementById("userDisplayName").innerText = googleName || user.email.split('@')[0];
    if (googleAvatar) {
      currentAvatarUrl = googleAvatar;
      renderAvatarImage(googleAvatar);
    } else {
      renderInitialAvatar();
    }
  }

  if (window.applyAccessControl) {
    await window.applyAccessControl();
  }

  updateProfileProgress();
}

function renderInitialAvatar() {
  currentAvatarUrl = null;
  const name = document.getElementById("fullNameInput").value.trim();
  const email = document.getElementById("emailInput").value.trim();

  let initial = "U";
  if (name) initial = name.charAt(0).toUpperCase();
  else if (email) initial = email.charAt(0).toUpperCase();

  document.getElementById("avatarContainer").innerText = initial;
  updateProfileProgress();
}

function renderAvatarImage(url) {
  if (!url) {
    renderInitialAvatar();
    return;
  }
  
  const cacheBustUrl = url.startsWith("data:") ? url : `${url}&t=${Date.now()}`;
  
  // Agar DiceBear ka SVG URL hai, toh direct image tag me daalne par kabhi-kabhi load nahi hota
  document.getElementById("avatarContainer").innerHTML = `
    <img src="${cacheBustUrl}" alt="Profile" style="width:100%; height:100%; border-radius:50%; object-fit:cover;" onerror="this.onerror=null; this.src='${url}';">
  `;
  updateProfileProgress();
}

function handleFileSelected(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    const cropImg = document.getElementById("cropTargetImage");
    cropImg.src = e.target.result;
    document.getElementById("cropModal").style.display = "flex";

    if (cropper) cropper.destroy();

    cropper = new Cropper(cropImg, {
      aspectRatio: 1,
      viewMode: 1,
      autoCropArea: 0.9,
      dragMode: 'move'
    });
  };
  reader.readAsDataURL(file);
  event.target.value = '';
}

function closeCropModal() {
  document.getElementById("cropModal").style.display = "none";
  if (cropper) cropper.destroy();
}

async function cropAndUpload() {
  if (!cropper || !currentUser) return;

  const canvas = cropper.getCroppedCanvas({ width: 300, height: 300 });
  closeCropModal();

  const msgBox = document.getElementById("statusMsg");
  msgBox.className = "status-msg";
  msgBox.innerText = "Saving cropped photo...";
  msgBox.style.display = "block";

  canvas.toBlob(async (blob) => {
    const filePath = `${currentUser.id}/avatar_${Date.now()}.png`;

    try {
      const { error: uploadErr } = await window.supabaseClient
        .storage
        .from('avatars')
        .upload(filePath, blob, { contentType: 'image/png', upsert: true });

      if (uploadErr) throw uploadErr;

      const { data: publicData } = window.supabaseClient
        .storage
        .from('avatars')
        .getPublicUrl(filePath);

      if (!publicData || !publicData.publicUrl) throw new Error("Failed to generate Public URL.");

      currentAvatarUrl = publicData.publicUrl;
      localStorage.setItem("userPhoto", currentAvatarUrl);

      renderAvatarImage(currentAvatarUrl);

      await window.supabaseClient
        .from('profiles')
        .upsert({ 
          id: currentUser.id, 
          email: currentUser.email,
          avatar_url: currentAvatarUrl, 
          updated_at: new Date().toISOString()
        });

      msgBox.className = "status-msg success";
      msgBox.innerText = "✅ Profile photo updated!";
      setTimeout(() => { msgBox.style.display = "none"; }, 3000);

    } catch (err) {
      console.error("Avatar Error:", err);
      msgBox.className = "status-msg error";
      msgBox.innerText = "❌ Upload failed: " + err.message;
    }
  }, 'image/png');
}

async function deleteAvatarPhoto() {
  closePhotoOptions();
  if (!currentUser) return;
  if (!confirm("Kya aap photo hatana chahte hain?")) return;

  const msgBox = document.getElementById("statusMsg");
  msgBox.className = "status-msg";
  msgBox.innerText = "Deleting photo...";
  msgBox.style.display = "block";

  try {
    const { error } = await window.supabaseClient
      .from('profiles')
      .update({ avatar_url: null, updated_at: new Date().toISOString() })
      .eq('id', currentUser.id);

    if (error) throw error;

    localStorage.removeItem("userPhoto");
    renderInitialAvatar();

    msgBox.className = "status-msg success";
    msgBox.innerText = "✅ Profile photo deleted!";
    setTimeout(() => { msgBox.style.display = "none"; }, 3000);
  } catch (err) {
    msgBox.className = "status-msg error";
    msgBox.innerText = "❌ Delete failed: " + err.message;
  }
}

async function saveProfileDetails() {
  if (!currentUser) return;

  const msgBox = document.getElementById("statusMsg");
  msgBox.className = "status-msg";

  const phone = document.getElementById("phoneInput").value.trim();

  if (phone !== "" && phone.length !== 10) {
    msgBox.className = "status-msg error";
    msgBox.innerText = "❌ Mobile number exactly 10 digits ka hona chahiye!";
    msgBox.style.display = "block";
    return;
  }

  msgBox.innerText = "Saving profile details...";
  msgBox.style.display = "block";

  const fullName = document.getElementById("fullNameInput").value.trim();
  const profileData = {
    id: currentUser.id,
    email: currentUser.email,
    full_name: fullName,
    country_code: document.getElementById("countryCodeSelect").value,
    phone: phone,
    target_class: document.getElementById("classSelect").value,
    stream: document.getElementById("streamSelect").value,
    institution: document.getElementById("institutionInput").value.trim(),
    city: document.getElementById("cityInput").value.trim(),
    state: document.getElementById("stateInput").value.trim(),
    pincode: document.getElementById("pincodeInput") ? document.getElementById("pincodeInput").value.trim() : "",
    avatar_url: currentAvatarUrl,
    updated_at: new Date().toISOString()
  };

  try {
    const { error } = await window.supabaseClient.from('profiles').upsert(profileData);
    if (error) throw error;

    if (fullName) {
      document.getElementById("userDisplayName").innerText = fullName;
    }

    updateProfileProgress();

    if (getCompletionPercentage() >= 100) {
      triggerCongratulationsAnimation();
    }

    msgBox.className = "status-msg success";
    msgBox.innerText = "✅ Profile info saved successfully!";
    setTimeout(() => { msgBox.style.display = "none"; }, 3000);
  } catch (err) {
    msgBox.className = "status-msg error";
    msgBox.innerText = "❌ Save failed: " + err.message;
  }
}

async function setGoogleUserPassword() {
  const newPassword = document.getElementById("newPasswordInput").value;
  if (!newPassword || newPassword.length < 6) {
    alert("Password kam se kam 6 characters ka hona chahiye!");
    return;
  }

  const { error } = await window.supabaseClient.auth.updateUser({ password: newPassword });

  if (error) {
    alert("❌ Password update failed: " + error.message);
  } else {
    alert("✅ Password successfully updated!");
    document.getElementById("newPasswordInput").value = "";
  }
}

async function clearAppCache() {
  try {
    // 1. Clear Service Worker / Cache Storage
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames.map(name => caches.delete(name))
      );
    }

    // 2. Preserve Auth Keys AND Notification Read/Delete Statuses
    const preservedItems = [];
    const keysToPreserve = ['read_notifs', 'deleted_notifs']; // <-- Notification states preserve karne ke liye

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        // Keep Supabase Auth & Notifications history intact
        if (key.startsWith('sb-') || key.includes('auth') || keysToPreserve.includes(key)) {
          preservedItems.push({ key, value: localStorage.getItem(key) });
        }
      }
    }

    // 3. Clear storage safely
    localStorage.clear();
    sessionStorage.clear();

    // 4. Restore preserved keys
    preservedItems.forEach(item => {
      localStorage.setItem(item.key, item.value);
    });

    alert("✅ App cache successfully cleared! Page reload ho raha hai.");
    window.location.reload();
  } catch (err) {
    console.error("Cache clear error:", err);
    alert("❌ Cache clear karne mein error aaya.");
  }
}

async function deleteUserAccount() {
  const emailInput = document.getElementById("deleteConfirmEmailInput").value.trim();
  
  if (!currentUser || emailInput.toLowerCase() !== currentUser.email.toLowerCase()) {
    alert("❌ Email match nahi hua! Account delete nahi kiya gaya.");
    return;
  }

  closeDeleteConfirmModal();

  const msgBox = document.getElementById("statusMsg");
  msgBox.className = "status-msg";
  msgBox.innerText = "Deleting account and cleaning database...";
  msgBox.style.display = "block";

  try {
    if (currentAvatarUrl && currentAvatarUrl.includes(currentUser.id)) {
      try {
        const path = currentAvatarUrl.split('/avatars/')[1];
        if (path) {
          await window.supabaseClient.storage.from('avatars').remove([path]);
        }
      } catch (stErr) {
        console.warn("Storage avatar cleanup skipped:", stErr);
      }
    }

    const { error: profileErr } = await window.supabaseClient
      .from('profiles')
      .delete()
      .eq('id', currentUser.id);

    if (profileErr) throw profileErr;

    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
    }

    localStorage.clear();
    sessionStorage.clear();
    await window.supabaseClient.auth.signOut();

    alert("✅ Aapka account safaltapoorvak permanently delete kar diya gaya hai.");
    window.location.href = window.getPageUrl ? window.getPageUrl("login.html") : "login.html";

  } catch (err) {
    console.error("Account Delete Error:", err);
    msgBox.className = "status-msg error";
    msgBox.innerText = "❌ Delete failed: " + err.message;
  }
}

// Navigation Helper Functions
function goToAdminPanel() { 
  window.location.href = "admin-panel.html"; 
}

function goToManageTeam() { 
  window.location.href = "manage-team.html"; 
}

function goToSendNotification() { 
  window.location.href = "admin-notifications.html"; 
}
function goToUploadFlashcard() { 
  window.location.href = "admin-flashcard-generator.html"; 
}

function goToManageFlashcard() { 
  window.location.href = "manage-flashcards.html"; 
}

function goToUploadTest() { 
  window.location.href = "admin-manage-tests.html"; 
}

function goToAiTestCreator() { 
  window.location.href = "admin-ai-test.html"; 
}

function goToUploadPyq() { 
  window.location.href = "admin-pyq-generator.html"; 
}

function goToManagePyq() { 
  window.location.href = "manage-pyqs.html"; 
}

function goToHome() { 
  window.location.href = "index.html"; 
}

// ---- Password section: default hidden, user tap kare tab dikhe ----
function togglePasswordSection() {
  const body = document.getElementById("passwordBody");
  const head = document.getElementById("passwordToggleHead");
  const icon = document.getElementById("passwordToggleIcon");
  const input = document.getElementById("newPasswordInput");
  if (!body) return;

  const willOpen = body.style.display === "none";
  body.style.display = willOpen ? "block" : "none";
  if (head) head.setAttribute("aria-expanded", String(willOpen));
  if (icon) icon.className = willOpen ? "fa-solid fa-chevron-up" : "fa-solid fa-chevron-down";
  if (willOpen && input) input.focus();
  if (!willOpen && input) input.value = "";
}

// ---- Logout: confirmation ke baad hi hoga (galti se tap par logout nahi) ----
function openLogoutConfirm() {
  const modal = document.getElementById("logoutConfirmModal");
  if (modal) modal.style.display = "flex";
}

function closeLogoutConfirm() {
  const modal = document.getElementById("logoutConfirmModal");
  if (modal) modal.style.display = "none";
}

function confirmLogout() {
  closeLogoutConfirm();
  logoutUser();
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeLogoutConfirm();
});

async function logoutUser() {
  try {
    await window.supabaseClient.auth.signOut();
  } catch (err) {
    console.error("Logout error:", err);
  }

  // Sirf Supabase session aur auth keys ko remove karein, baki local storage (preferences/cookies) safe rahegi
  Object.keys(localStorage).forEach(key => {
    if (key.startsWith('sb-') || key.includes('auth')) {
      localStorage.removeItem(key);
    }
  });

  sessionStorage.clear();
  
  // window.location.replace use karne se browser history mein page replace ho jayega aur back button kaam nahi karega
  window.location.replace("index.html");
}
async function checkAndSyncSecureStreak() {
  if (typeof window.supabaseClient === 'undefined') return;

  try {
    const { data: { session } } = await window.supabaseClient.auth.getSession();
    if (!session) return; // Agar user login nahi hai toh skip karein

    const userId = session.user.id;
    const todayStr = new Date().toISOString().split('T')[0];

    // 1. Database se current user ka streak data fetch karein
    let { data: profile, error } = await window.supabaseClient
      .from('profiles')
      .select('current_streak, last_active_date')
      .eq('id', userId)
      .single();

    if (error) {
      console.warn("Streak fetch error:", error);
      return;
    }

    let currentStreak = profile?.current_streak || 0;
    let lastActive = profile?.last_active_date ? profile.last_active_date.split('T')[0] : null;

    if (lastActive === todayStr) {
      // Aaj already streak count ho chuki hai
      return currentStreak;
    }

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    if (lastActive === yesterdayStr) {
      // Streak continues! (+1)
      currentStreak += 1;
    } else if (!lastActive || lastActive < yesterdayStr) {
      // Streak toot gayi ya pehla din hai
      currentStreak = 1;
    }

    // 2. Securely Database me update karein (Console hack se safe)
    const { error: updateErr } = await window.supabaseClient
      .from('profiles')
      .update({
        current_streak: currentStreak,
        last_active_date: todayStr
      })
      .eq('id', userId);

    if (updateErr) {
      console.warn("Streak update failed:", updateErr);
    } else {
      console.log(`Secure Streak Updated: 🔥 ${currentStreak} Days`);
    }

    return currentStreak;
  } catch (err) {
    console.warn("Streak sync error:", err);
  }
}

// App load hone par call karein
document.addEventListener('DOMContentLoaded', () => {
  checkAndSyncSecureStreak();
});
